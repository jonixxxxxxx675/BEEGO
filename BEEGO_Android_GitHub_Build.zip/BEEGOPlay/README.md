# BEEGO — Android / Google Play starter

Це нативний Android-проєкт, який пакує локальний BEEGO HTML/JS-прототип у WebView.

## Важливо
Це **Play-ready starter**, а не вже опублікований комерційний сервіс. Для реального запуску потрібні backend, реальна оплата, авторизація, GPS/карти, push, ресторанний кабінет, дронова диспетчеризація, privacy policy, Data Safety та підпис релізу.

## Вимоги
- Android Studio Ladybug/новіше з Android SDK 36
- JDK 17
- Gradle 8.13+ / Android Gradle Plugin 8.13+

## Збірка
В Android Studio відкрий папку `BEEGOPlay`, дочекайся Gradle Sync, потім:
Build → Generate Signed App Bundle / APK → Android App Bundle.

Для Google Play використовуй **AAB**, створи upload key і Play App Signing.

На 31 серпня 2026 для нових застосунків Google Play вимагає target Android 16 / API 36.


## Build without Android Studio

This project includes a GitHub Actions workflow.

1. Create a GitHub repository.
2. Upload the contents of this `BEEGOPlay` folder.
3. Open the repository's **Actions** tab.
4. Run **BEEGO Android Build**.
5. When it finishes, open the workflow run and download:
   - `BEEGO-debug-APK` for installing on an Android phone for testing.
   - `BEEGO-release-AAB` for the Google Play release pipeline.

The release AAB is not yet Play-publishable until a proper release signing setup, privacy/data-safety declarations, store assets, and the production backend/services are added.
