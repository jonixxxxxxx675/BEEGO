plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.beego.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.beego.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 20
        versionName = "5.1.0"
    }

    buildFeatures { buildConfig = true }

    // Test release signing. A private keystore should be used before public distribution.
    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("org.osmdroid:osmdroid-android:6.1.20")
}

kotlin { jvmToolchain(17) }
