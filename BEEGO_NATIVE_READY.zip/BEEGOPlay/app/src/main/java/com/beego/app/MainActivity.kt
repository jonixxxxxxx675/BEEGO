package com.beego.app

import android.app.Activity
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Space
import android.widget.TextView

class MainActivity : Activity() {

    private val bg = Color.rgb(7, 9, 9)
    private val yellow = Color.rgb(255, 193, 7)
    private val white = Color.WHITE
    private val muted = Color.rgb(170, 174, 178)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var title: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        hideSystemBars()
        buildShell()
        showHome()
    }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(20, 16, 20, 12)
        }

        title = TextView(this).apply {
            text = "BEEGO"
            textSize = 24f
            setTextColor(yellow)
            typeface = Typeface.DEFAULT_BOLD
        }

        val cart = Button(this).apply {
            text = "🛒"
            textSize = 20f
            setTextColor(white)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { showCart() }
        }

        header.addView(title, LinearLayout.LayoutParams(0, 58, 1f))
        header.addView(cart, LinearLayout.LayoutParams(58, 58))
        root.addView(header)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 0, 18, 24)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(6, 6, 6, 8)
            setBackgroundColor(Color.rgb(15, 17, 17))
        }
        addNav(nav, "⌂", "Головна") { showHome() }
        addNav(nav, "🍔", "Меню") { showMenu() }
        addNav(nav, "🚁", "Дрон") { showTrack() }
        addNav(nav, "📍", "Хаби") { showHubs() }
        addNav(nav, "👤", "Профіль") { showProfile() }
        root.addView(nav, LinearLayout.LayoutParams(-1, 68))

        setContentView(root)
    }

    private fun addNav(parent: LinearLayout, icon: String, label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = "$icon\n$label"
            textSize = 11f
            setTextColor(white)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { action() }
        }
        parent.addView(b, LinearLayout.LayoutParams(0, 60, 1f))
    }

    private fun clear(titleText: String) {
        title.text = "BEEGO"
        content.removeAllViews()
        addText(titleText, 28f, white, true, 8)
    }

    private fun addText(text: String, size: Float, color: Int, bold: Boolean = false, top: Int = 10) {
        val t = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, top, 0, 8)
        }
        content.addView(t, LinearLayout.LayoutParams(-1, -2))
    }

    private fun addButton(text: String, action: () -> Unit) {
        val b = Button(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(Color.BLACK)
            setBackgroundColor(yellow)
            isAllCaps = false
            setOnClickListener { action() }
            minHeight = 54
        }
        val lp = LinearLayout.LayoutParams(-1, 54)
        lp.setMargins(0, 8, 0, 8)
        content.addView(b, lp)
    }

    private fun addCard(text: String, action: (() -> Unit)? = null) {
        val b = Button(this).apply {
            this.text = text
            textSize = 17f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(white)
            setBackgroundColor(Color.rgb(25, 28, 28))
            isAllCaps = false
            if (action != null) setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, 74)
        lp.setMargins(0, 7, 0, 7)
        content.addView(b, lp)
    }

    private fun addImage(asset: String, height: Int) {
        try {
            val bitmap = assets.open(asset).use { BitmapFactory.decodeStream(it) }
            val image = ImageView(this).apply {
                setImageBitmap(bitmap)
                scaleType = ImageView.ScaleType.CENTER_CROP
                adjustViewBounds = true
            }
            val lp = LinearLayout.LayoutParams(-1, height)
            lp.setMargins(0, 4, 0, 14)
            content.addView(image, lp)
        } catch (_: Exception) {}
    }

    private fun showHome() {
        clear("Львів завжди ближче")
        addImage("hero.jpg", 220)
        addText("FOOD DELIVERY BY AIR", 16f, yellow, true, 0)
        addText("Замовляй їжу — BEEGO доставить її дроном.", 17f, white, false, 2)
        addButton("Почати замовлення") { showMenu() }
        addCard("🍔 Бургери та швидка їжа") { showMenu() }
        addCard("🚁 Доставка дроном") { showTrack() }
        addCard("📍 BEEGO HUB у Львові") { showHubs() }
        addText("🌱 Менше заторів • менше викидів • швидша доставка", 14f, muted, false, 18)
    }

    private fun showMenu() {
        clear("Меню")
        addImage("burger.jpg", 190)
        addText("Популярне", 20f, yellow, true, 0)
        addCard("🍔 BEEGO Burger — 189 zł") { showProduct("BEEGO Burger", "189 zł") }
        addCard("🍟 Crispy Fries — 79 zł") { showProduct("Crispy Fries", "79 zł") }
        addCard("🥤 Fresh Drink — 59 zł") { showProduct("Fresh Drink", "59 zł") }
        addText("Обери товар, щоб переглянути деталі.", 14f, muted)
    }

    private fun showProduct(name: String, price: String) {
        clear(name)
        addImage("burger.jpg", 230)
        addText(name, 26f, white, true, 0)
        addText(price, 22f, yellow, true, 2)
        addText("Свіжоприготована страва. Доставка BEEGO дроном у доступну зону.", 16f, muted)
        addButton("Додати в кошик") { showCart() }
        addButton("← Назад до меню") { showMenu() }
    }

    private fun showCart() {
        clear("Кошик")
        addCard("BEEGO Burger                 189 zł")
        addCard("Доставка дроном              29 zł")
        addText("Разом                          218 zł", 22f, yellow, true, 20)
        addButton("Оформити замовлення") { showTrack() }
        addButton("← Повернутися до меню") { showMenu() }
    }

    private fun showTrack() {
        clear("Відстеження")
        addImage("drone.jpg", 210)
        addText("🚁 Дрон уже в польоті", 23f, yellow, true, 0)
        addText("Статус: замовлення забрано\nМаршрут: ресторан → BEEGO HUB\nОрієнтовно: 8 хв", 17f, white)
        addCard("📍 Дрон летить до вашого HUB")
        addButton("Замовлення доставлено") { showDelivered() }
    }

    private fun showDelivered() {
        clear("Доставлено")
        addText("✓", 64f, yellow, true, 18)
        addText("Замовлення доставлено!", 28f, white, true, 0)
        addText("Дякуємо, що користуєшся BEEGO.", 17f, muted)
        addButton("Нове замовлення") { showMenu() }
    }

    private fun showHubs() {
        clear("BEEGO HUB")
        addCard("📍 Площа Ринок — HUB 01")
        addCard("📍 Сихів — HUB 02")
        addCard("📍 Наукова — HUB 03")
        addCard("📍 Левандівка — HUB 04")
        addText("HUB — безпечна точка прийому та видачі замовлень.", 15f, muted, false, 18)
    }

    private fun showProfile() {
        clear("Профіль")
        addText("👤 Мій профіль", 22f, white, true, 4)
        addCard("📦 Історія замовлень")
        addCard("📍 Мої адреси")
        addCard("💳 Способи оплати")
        addCard("⭐ BEEGO Plus") { showPlus() }
        addCard("⚙️ Налаштування")
    }

    private fun showPlus() {
        clear("BEEGO Plus")
        addText("⭐ BEEGO PLUS", 28f, yellow, true, 4)
        addText("Преміум-доставка та додаткові переваги.", 18f, white)
        addCard("🚁 Пріоритетна доставка")
        addCard("🎁 Спеціальні пропозиції")
        addCard("📦 Знижки на доставку")
        addButton("Підключити BEEGO Plus") { showProfile() }
    }

    private fun hideSystemBars() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        showHome()
    }
}
