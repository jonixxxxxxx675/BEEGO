package com.beego.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 10, 10)
    private val panel = Color.rgb(25, 28, 28)
    private val panel2 = Color.rgb(33, 36, 36)
    private val yellow = Color.rgb(255, 193, 7)
    private val white = Color.WHITE
    private val muted = Color.rgb(180, 184, 187)
    private val green = Color.rgb(92, 200, 120)

    private data class Product(
        val name: String,
        val category: String,
        val price: Int,
        val emoji: String,
        val description: String
    )

    private val products = listOf(
        Product("BEEGO Burger", "Бургери", 189, "🍔", "Соковита яловичина, сир, салат, томат і фірмовий соус."),
        Product("Chicken Crispy", "Бургери", 179, "🍗", "Хрустка курка, салат, сир та легкий фірмовий соус."),
        Product("City Pizza", "Піца", 159, "🍕", "Моцарела, томати, пепероні та базилік на тонкому тісті."),
        Product("Four Cheese", "Піца", 179, "🧀", "Моцарела, чедер, дорблю та пармезан."),
        Product("Crispy Fries", "Закуски", 79, "🍟", "Хрустка картопля з сіллю та фірмовим соусом."),
        Product("Chicken Wings", "Закуски", 129, "🍗", "Курячі крильця з хрусткою скоринкою та соусом."),
        Product("Fresh Lemonade", "Напої", 59, "🥤", "Холодний лимонад з лимоном та м'ятою."),
        Product("Cola Zero", "Напої", 49, "🥤", "Охолоджений напій без цукру."),
        Product("Cheesecake", "Десерти", 89, "🍰", "Ніжний вершковий чизкейк з ягідним соусом.")
    )

    private val cart = linkedMapOf<String, Int>()
    private lateinit var content: LinearLayout
    private var selectedCategory = "Усе"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Safe legacy immersive mode: no WindowInsets callbacks and no focus-loop.
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        showMenu()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 18): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun shell(title: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(10), dp(12), dp(8))
        }

        val logo = TextView(this).apply {
            text = "🐝  BEEGO"
            textSize = 23f
            setTextColor(yellow)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(logo, LinearLayout.LayoutParams(0, dp(54), 1f))

        val cartButton = Button(this).apply {
            text = if (cartCount() > 0) "🛒 ${cartCount()}" else "🛒"
            textSize = 15f
            setTextColor(white)
            background = rounded(panel2, 16)
            isAllCaps = false
            setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { showCart() }
        }
        header.addView(cartButton, LinearLayout.LayoutParams(dp(82), dp(48)))
        root.addView(header)

        val titleView = TextView(this).apply {
            text = title
            textSize = 15f
            setTextColor(muted)
            setPadding(dp(18), 0, dp(18), dp(6))
        }
        root.addView(titleView)

        val scroll = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(4), dp(18), dp(24))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(panel)
            setPadding(0, dp(4), 0, dp(4))
        }
        navButton(nav, "⌂", "Головна") { showHome() }
        navButton(nav, "🍔", "Меню") { showMenu() }
        navButton(nav, "🚁", "Дрон") { showTrack() }
        navButton(nav, "📍", "HUB") { showHubs() }
        navButton(nav, "👤", "Профіль") { showProfile() }
        root.addView(nav, LinearLayout.LayoutParams(-1, dp(70)))

        setContentView(root)
    }

    private fun navButton(parent: LinearLayout, icon: String, label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = "$icon\n$label"
            textSize = 10f
            setTextColor(white)
            background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            isAllCaps = false
            setOnClickListener { action() }
        }
        parent.addView(b, LinearLayout.LayoutParams(0, dp(62), 1f))
    }

    private fun heading(value: String, size: Float = 29f) {
        val t = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), 0, dp(8))
        }
        content.addView(t)
    }

    private fun body(value: String, size: Float = 16f, color: Int = muted) {
        val t = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            setPadding(0, dp(2), 0, dp(8))
        }
        content.addView(t)
    }

    private fun sectionLabel(value: String) {
        val t = TextView(this).apply {
            text = value.uppercase()
            textSize = 12f
            setTextColor(yellow)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(18), 0, dp(8))
        }
        content.addView(t)
    }

    private fun categoryBar() {
        val hsv = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val cats = listOf("Усе", "Бургери", "Піца", "Закуски", "Напої", "Десерти")
        cats.forEach { cat ->
            val b = Button(this).apply {
                text = cat
                textSize = 13f
                setTextColor(if (cat == selectedCategory) Color.BLACK else white)
                background = rounded(if (cat == selectedCategory) yellow else panel2, 20)
                isAllCaps = false
                setPadding(dp(15), 0, dp(15), 0)
                setOnClickListener {
                    selectedCategory = cat
                    showMenu()
                }
            }
            val lp = LinearLayout.LayoutParams(dp(104), dp(44))
            lp.setMargins(0, 0, dp(8), 0)
            row.addView(b, lp)
        }
        hsv.addView(row)
        content.addView(hsv, LinearLayout.LayoutParams(-1, dp(50)))
    }

    private fun productCard(p: Product) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(panel, 18)
            setOnClickListener { showProduct(p) }
        }

        val icon = TextView(this).apply {
            text = p.emoji
            textSize = 38f
            gravity = Gravity.CENTER
            background = rounded(panel2, 14)
        }
        card.addView(icon, LinearLayout.LayoutParams(dp(76), dp(76)))

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(8), 0)
        }
        val name = TextView(this).apply {
            text = p.name
            textSize = 18f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        info.addView(name)
        val desc = TextView(this).apply {
            text = p.description
            textSize = 12f
            setTextColor(muted)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        info.addView(desc)
        val price = TextView(this).apply {
            text = "${p.price} ₴"
            textSize = 16f
            setTextColor(yellow)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(5), 0, 0)
        }
        info.addView(price)
        card.addView(info, LinearLayout.LayoutParams(0, dp(86), 1f))

        val add = Button(this).apply {
            text = "+"
            textSize = 27f
            setTextColor(Color.BLACK)
            background = rounded(yellow, 16)
            setOnClickListener {
                cart[p.name] = (cart[p.name] ?: 0) + 1
                showMenu()
            }
        }
        card.addView(add, LinearLayout.LayoutParams(dp(54), dp(54)))

        val lp = LinearLayout.LayoutParams(-1, dp(100))
        lp.setMargins(0, 0, 0, dp(10))
        content.addView(card, lp)
    }

    private fun showMenu() {
        shell("Меню • Львів")
        heading("Що замовимо?", 28f)
        body("Їжа з ресторанів міста — зручно замовити та доставити BEEGO.", 15f)
        categoryBar()

        val list = if (selectedCategory == "Усе") products else products.filter { it.category == selectedCategory }
        sectionLabel(if (selectedCategory == "Усе") "Популярне" else selectedCategory)
        list.forEach { productCard(it) }

        body("🚁 Доставка дроном доступна в зонах покриття BEEGO.", 13f)
    }

    private fun showProduct(p: Product) {
        shell("Товар")
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(panel, 22)
            setPadding(dp(16), dp(22), dp(16), dp(22))
        }
        val emoji = TextView(this).apply { text = p.emoji; textSize = 76f; gravity = Gravity.CENTER }
        hero.addView(emoji, LinearLayout.LayoutParams(-1, dp(115)))
        val title = TextView(this).apply {
            text = p.name
            textSize = 27f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        hero.addView(title)
        val price = TextView(this).apply {
            text = "${p.price} ₴"
            textSize = 24f
            setTextColor(yellow)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(4))
        }
        hero.addView(price)
        val desc = TextView(this).apply {
            text = p.description
            textSize = 15f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(5), dp(8), dp(10))
        }
        hero.addView(desc)
        content.addView(hero, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))

        val add = Button(this).apply {
            text = "Додати в кошик • ${p.price} ₴"
            textSize = 17f
            setTextColor(Color.BLACK)
            background = rounded(yellow, 17)
            isAllCaps = false
            setOnClickListener {
                cart[p.name] = (cart[p.name] ?: 0) + 1
                showProduct(p)
            }
        }
        val addLp = LinearLayout.LayoutParams(-1, dp(58)); addLp.setMargins(0, dp(14), 0, dp(8))
        content.addView(add, addLp)

        secondaryButton("Перейти до кошика") { showCart() }
        secondaryButton("← Повернутися до меню") { showMenu() }
    }

    private fun secondaryButton(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = 15f
            setTextColor(white)
            background = rounded(panel2, 16)
            isAllCaps = false
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, dp(52)); lp.setMargins(0, dp(6), 0, dp(6))
        content.addView(b, lp)
    }

    private fun cartCount(): Int = cart.values.sum()

    private fun showCart() {
        shell("Кошик")
        heading("Кошик", 29f)
        if (cart.isEmpty()) {
            body("🛒 Кошик порожній.", 18f, white)
            body("Обери страви в меню — вони з'являться тут.")
            secondaryButton("Перейти до меню") { showMenu() }
            return
        }

        var subtotal = 0
        cart.entries.toList().forEach { entry ->
            val p = products.firstOrNull { it.name == entry.key } ?: return@forEach
            val qty = entry.value
            subtotal += p.price * qty
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = rounded(panel, 16)
            }
            val name = TextView(this).apply {
                text = "${p.emoji}  ${p.name}\n$qty × ${p.price} ₴"
                textSize = 15f
                setTextColor(white)
            }
            row.addView(name, LinearLayout.LayoutParams(0, dp(64), 1f))
            val minus = Button(this).apply {
                text = "−"; textSize = 20f; setTextColor(white); background = rounded(panel2, 12)
                setOnClickListener {
                    if (qty <= 1) cart.remove(p.name) else cart[p.name] = qty - 1
                    showCart()
                }
            }
            row.addView(minus, LinearLayout.LayoutParams(dp(48), dp(48)))
            val plus = Button(this).apply {
                text = "+"; textSize = 20f; setTextColor(Color.BLACK); background = rounded(yellow, 12)
                setOnClickListener { cart[p.name] = qty + 1; showCart() }
            }
            val plusLp = LinearLayout.LayoutParams(dp(48), dp(48)); plusLp.setMargins(dp(6), 0, 0, 0)
            row.addView(plus, plusLp)
            val lp = LinearLayout.LayoutParams(-1, dp(84)); lp.setMargins(0, 0, 0, dp(8))
            content.addView(row, lp)
        }

        sectionLabel("Підсумок")
        body("Сума страв: $subtotal ₴", 16f, white)
        body("Доставка BEEGO: 29 ₴", 16f, white)
        heading("Разом: ${subtotal + 29} ₴", 24f)
        val order = Button(this).apply {
            text = "Оформити замовлення"
            textSize = 17f
            setTextColor(Color.BLACK)
            background = rounded(yellow, 17)
            isAllCaps = false
            setOnClickListener { showTrack() }
        }
        content.addView(order, LinearLayout.LayoutParams(-1, dp(58)))
        secondaryButton("← Продовжити покупки") { showMenu() }
    }

    private fun showHome() {
        shell("BEEGO")
        heading("Львів завжди ближче", 27f)
        body("Замовляй їжу — BEEGO доставляє її повітрям.", 17f, white)
        val b = Button(this).apply {
            text = "Відкрити меню"
            textSize = 17f
            setTextColor(Color.BLACK)
            background = rounded(yellow, 17)
            isAllCaps = false
            setOnClickListener { showMenu() }
        }
        content.addView(b, LinearLayout.LayoutParams(-1, dp(58)))
    }

    private fun showTrack() {
        shell("Доставка")
        heading("🚁 Дрон у польоті", 25f)
        body("Замовлення готується до доставки.", 17f, white)
        secondaryButton("● Ресторан → HUB") {}
        secondaryButton("● Дрон летить до точки отримання") {}
        body("Орієнтовний час: 8 хв", 18f, yellow)
        secondaryButton("Повернутися до меню") { showMenu() }
    }

    private fun showHubs() {
        shell("BEEGO HUB")
        heading("BEEGO HUB")
        listOf("📍 Площа Ринок — HUB 01", "📍 Сихів — HUB 02", "📍 Наукова — HUB 03", "📍 Левандівка — HUB 04").forEach { secondaryButton(it) {} }
        body("Безпечні точки прийому та видачі замовлень.")
    }

    private fun showProfile() {
        shell("Профіль")
        heading("👤 Мій профіль")
        secondaryButton("📦 Історія замовлень") {}
        secondaryButton("📍 Мої адреси") {}
        secondaryButton("💳 Способи оплати") {}
        secondaryButton("⭐ BEEGO Plus") {}
    }
}
