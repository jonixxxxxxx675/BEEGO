package com.beego.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.WindowInsets
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 10, 10)
    private val panel = Color.rgb(25, 28, 28)
    private val panel2 = Color.rgb(33, 36, 36)
    private val yellow = Color.rgb(255, 193, 7)
    private val white = Color.WHITE
    private val muted = Color.rgb(180, 184, 187)
    private val green = Color.rgb(92, 200, 120)

    private data class Product(
        val name: String,
        val category: String,
        val price: Int,
        val emoji: String,
        val description: String
    )

    private data class AddOn(
        val name: String,
        val price: Int
    )

    private val products = listOf(
        Product("BEEGO Burger", "Бургери", 189, "🍔", "Соковита яловичина, сир, салат, томат і фірмовий соус."),
        Product("Chicken Crispy", "Бургери", 179, "🍗", "Хрустка курка, салат, сир та легкий фірмовий соус."),
        Product("City Pizza", "Піца", 160, "🍕", "Моцарела, томати, пепероні та базилік на тонкому тісті."),
        Product("Four Cheese", "Піца", 179, "🧀", "Моцарела, чедер, дорблю та пармезан."),
        Product("Crispy Fries", "Закуски", 79, "🍟", "Хрустка картопля з сіллю та фірмовим соусом."),
        Product("Chicken Wings", "Закуски", 129, "🍗", "Курячі крильця з хрусткою скоринкою та соусом."),
        Product("Fresh Lemonade", "Напої", 60, "🥤", "Холодний лимонад з лимоном та м'ятою."),
        Product("Cola Zero", "Напої", 49, "🥤", "Охолоджений напій без цукру."),
        Product("Cheesecake", "Десерти", 89, "🍰", "Ніжний вершковий чизкейк з ягідним соусом.")
    )

    private val cart = linkedMapOf<String, Int>()
    private lateinit var content: LinearLayout
    private var selectedCategory = "Усе"
    private var selectedHub: String? = null
    private var orderConfirmed = false
    private var trackingStage = 0
    private var paymentMethod = "💳 Банківська картка"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // True fullscreen for modern Android, including Android 15/16.
        // The bars are hidden again when the window regains focus, without
        // installing an Insets listener that could cause a focus loop.
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        hideSystemBars()
        showHome()
    }

    private fun hideSystemBars() {
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.systemBars())
                controller.systemBarsBehavior =
                    android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 18): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun shell(title: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(10), dp(12), dp(8))
        }

        val logo = TextView(this).apply {
            text = "🐝  BEEGO"
            textSize = 23f
            setTextColor(yellow)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(logo, LinearLayout.LayoutParams(0, dp(54), 1f))

        val cartButton = Button(this).apply {
            text = if (cartCount() > 0) "🛒 ${cartCount()}" else "🛒"
            textSize = 15f
            setTextColor(white)
            background = rounded(panel2, 16)
            isAllCaps = false
            setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { showCart() }
        }
        header.addView(cartButton, LinearLayout.LayoutParams(dp(82), dp(48)))
        root.addView(header)

        val titleView = TextView(this).apply {
            text = title
            textSize = 15f
            setTextColor(muted)
            setPadding(dp(18), 0, dp(18), dp(6))
        }
        root.addView(titleView)

        val scroll = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(4), dp(18), dp(24))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(panel)
            setPadding(0, dp(4), 0, dp(4))
        }
        navButton(nav, "⌂", "Головна") { showHome() }
        navButton(nav, "🍔", "Меню") { showMenu() }
        navButton(nav, "🚁", "Дрон") { showTrack() }
        navButton(nav, "📍", "HUB") { showHubs() }
        navButton(nav, "👤", "Профіль") { showProfile() }
        root.addView(nav, LinearLayout.LayoutParams(-1, dp(70)))

        root.alpha = 0f
        setContentView(root)
        root.animate().alpha(1f).setDuration(140L).start()
    }

    private fun navButton(parent: LinearLayout, icon: String, label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = "$icon\n$label"
            textSize = 10f
            setTextColor(white)
            background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            isAllCaps = false
            setOnClickListener { action() }
        }
        parent.addView(b, LinearLayout.LayoutParams(0, dp(62), 1f))
    }

    private fun heading(value: String, size: Float = 29f) {
        val t = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), 0, dp(8))
        }
        content.addView(t)
    }

    private fun body(value: String, size: Float = 16f, color: Int = muted) {
        val t = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            setPadding(0, dp(2), 0, dp(8))
        }
        content.addView(t)
    }

    private fun sectionLabel(value: String) {
        val t = TextView(this).apply {
            text = value.uppercase()
            textSize = 12f
            setTextColor(yellow)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(18), 0, dp(8))
        }
        content.addView(t)
    }

    private fun categoryBar() {
        val hsv = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(2), dp(4), dp(4))
        }
        val cats = listOf("Усе", "Бургери", "Піца", "Закуски", "Напої", "Десерти")
        cats.forEach { cat ->
            val b = TextView(this).apply {
                text = cat
                textSize = 14f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(if (cat == selectedCategory) Color.BLACK else white)
                background = rounded(if (cat == selectedCategory) yellow else panel2, 24)
                setPadding(dp(20), 0, dp(20), 0)
                setOnClickListener {
                    selectedCategory = cat
                    showMenu()
                }
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46))
            lp.setMargins(0, 0, dp(9), 0)
            row.addView(b, lp)
        }
        hsv.addView(row)
        content.addView(hsv, LinearLayout.LayoutParams(-1, dp(54)))
    }

    private fun productAsset(p: Product): String? = when (p.name) {
        "BEEGO Burger" -> "product_burger.png"
        "Chicken Crispy" -> "product_chicken_crispy.png"
        "City Pizza" -> "product_city_pizza.png"
        "Four Cheese" -> "product_four_cheese.png"
        "Crispy Fries" -> "product_fries.png"
        "Chicken Wings" -> "product_wings.png"
        "Fresh Lemonade" -> "product_lemonade.png"
        "Cola Zero" -> "product_cola.png"
        else -> null
    }

    private fun productCard(p: Product) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel, 22)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { showProduct(p) }
        }

        val media = FrameLayout(this).apply {
            background = rounded(panel2, 18)
            clipToOutline = true
        }
        val asset = productAsset(p)
        if (asset != null) {
            val image = ImageView(this).apply {
                setImageBitmap(android.graphics.BitmapFactory.decodeStream(assets.open(asset)))
                scaleType = ImageView.ScaleType.CENTER_CROP
                clipToOutline = true
            }
            media.addView(image, FrameLayout.LayoutParams(-1, -1))
        } else {
            val icon = TextView(this).apply {
                text = p.emoji
                textSize = 48f
                gravity = Gravity.CENTER
                setTextColor(white)
            }
            media.addView(icon, FrameLayout.LayoutParams(-1, -1))
        }

        val hit = TextView(this).apply {
            text = if (p.name == "BEEGO Burger") "ХІТ" else ""
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            background = rounded(yellow, 12)
            if (text.isEmpty()) visibility = View.GONE
        }
        val hitLp = FrameLayout.LayoutParams(dp(48), dp(28), Gravity.TOP or Gravity.START)
        hitLp.setMargins(dp(8), dp(8), 0, 0)
        media.addView(hit, hitLp)
        card.addView(media, LinearLayout.LayoutParams(-1, dp(128)))

        val name = TextView(this).apply {
            text = p.name
            textSize = 17f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(dp(4), dp(9), dp(4), 0)
        }
        card.addView(name)

        val desc = TextView(this).apply {
            text = p.description
            textSize = 11.5f
            setTextColor(muted)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(dp(4), dp(2), dp(4), 0)
        }
        card.addView(desc, LinearLayout.LayoutParams(-1, dp(34)))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(4), 0, 0)
        }
        val price = TextView(this).apply {
            text = "${p.price} ₴"
            textSize = 17f
            setTextColor(yellow)
            typeface = Typeface.DEFAULT_BOLD
        }
        bottom.addView(price, LinearLayout.LayoutParams(0, dp(46), 1f))

        val add = TextView(this).apply {
            text = "+"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            background = rounded(yellow, 15)
            setOnClickListener {
                cart[p.name] = (cart[p.name] ?: 0) + 1
                showMenu()
            }
        }
        bottom.addView(add, LinearLayout.LayoutParams(dp(48), dp(46)))
        card.addView(bottom)

        val lp = LinearLayout.LayoutParams(0, dp(256), 1f)
        lp.setMargins(dp(0), 0, dp(8), dp(10))
        currentRow?.addView(card, lp)
    }

    private var currentRow: LinearLayout? = null

    private fun showMenu() {
        shell("Меню • Львів")

        heading("Що замовимо?", 29f)
        body("Їжа з ресторанів міста — швидко, зручно та BEEGO.", 15f)

        val search = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), 0, dp(14), 0)
            background = rounded(panel2, 18)
        }
        val icon = TextView(this).apply {
            text = "⌕"
            textSize = 26f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }
        search.addView(icon, LinearLayout.LayoutParams(dp(36), dp(52)))
        val hint = TextView(this).apply {
            text = "Пошук страв, бургерів, піци..."
            textSize = 14f
            setTextColor(muted)
        }
        search.addView(hint, LinearLayout.LayoutParams(0, dp(52), 1f))
        val filter = TextView(this).apply {
            text = "≡"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(white)
            setOnClickListener { bodyToast("Фільтри BEEGO") }
        }
        search.addView(filter, LinearLayout.LayoutParams(dp(38), dp(52)))
        content.addView(search, LinearLayout.LayoutParams(-1, dp(52)))

        categoryBar()
        sectionLabel(if (selectedCategory == "Усе") "Популярне" else selectedCategory)

        val list = if (selectedCategory == "Усе") products else products.filter { it.category == selectedCategory }
        var index = 0
        while (index < list.size) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.TOP
            }
            currentRow = row
            productCard(list[index])
            if (index + 1 < list.size) productCard(list[index + 1])
            currentRow = null
            content.addView(row, LinearLayout.LayoutParams(-1, dp(268)))
            index += 2
        }

        val note = TextView(this).apply {
            text = "🚁 Доставка дроном доступна в зонах покриття BEEGO."
            textSize = 13f
            setTextColor(muted)
            setPadding(0, dp(8), 0, dp(10))
        }
        content.addView(note)
    }

    private fun addOnsFor(p: Product): List<AddOn> = when (p.name) {
        "BEEGO Burger" -> listOf(AddOn("Сир чеддер", 20), AddOn("Бекон", 30), AddOn("Подвійна котлета", 50))
        "Chicken Crispy" -> listOf(AddOn("Сир чеддер", 20), AddOn("Бекон", 25), AddOn("Гострий соус", 15))
        "City Pizza" -> listOf(AddOn("Додатковий сир", 25), AddOn("Пепероні", 30), AddOn("Гриби", 20))
        "Four Cheese" -> listOf(AddOn("Додатковий чеддер", 20), AddOn("Дорблю", 25), AddOn("Пармезан", 20))
        "Crispy Fries" -> listOf(AddOn("Сирний соус", 15), AddOn("Бекон", 25), AddOn("Халапеньйо", 15))
        "Chicken Wings" -> listOf(AddOn("Гострий соус", 15), AddOn("Сирний соус", 15), AddOn("Додаткова порція", 35))
        "Fresh Lemonade" -> listOf(AddOn("М'ята", 10), AddOn("Лимон", 10), AddOn("Подвійний об'єм", 25))
        "Cola Zero" -> listOf(AddOn("Лід", 0), AddOn("Лимон", 10), AddOn("Подвійний об'єм", 20))
        "Cheesecake" -> listOf(AddOn("Ягідний соус", 15), AddOn("Полуниця", 20), AddOn("Шоколад", 20))
        else -> listOf(AddOn("Додатковий соус", 15), AddOn("Сир", 20), AddOn("Подвійна порція", 35))
    }

    private fun showProduct(p: Product) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val top = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }

        val back = TextView(this).apply {
            text = "‹"
            textSize = 48f
            setTextColor(white)
            gravity = Gravity.CENTER
            setOnClickListener { showMenu() }
        }
        val backLp = FrameLayout.LayoutParams(dp(60), dp(60), Gravity.TOP or Gravity.START)
        backLp.setMargins(dp(8), dp(8), 0, 0)
        top.addView(back, backLp)

        val favorite = TextView(this).apply {
            text = "♡"
            textSize = 38f
            setTextColor(white)
            gravity = Gravity.CENTER
            setOnClickListener {
                text = if (text == "♡") "♥" else "♡"
            }
        }
        val favLp = FrameLayout.LayoutParams(dp(60), dp(60), Gravity.TOP or Gravity.END)
        favLp.setMargins(0, dp(8), dp(8), 0)
        top.addView(favorite, favLp)

        val asset = productAsset(p)
        if (asset != null) {
            val image = ImageView(this).apply {
                setImageBitmap(android.graphics.BitmapFactory.decodeStream(assets.open(asset)))
                scaleType = ImageView.ScaleType.CENTER_CROP
                contentDescription = p.name
            }
            val imageLp = FrameLayout.LayoutParams(-1, -1)
            top.addView(image, imageLp)
            top.bringChildToFront(back)
            top.bringChildToFront(favorite)
        } else {
            val media = LinearLayout(this).apply {
                gravity = Gravity.CENTER
                background = rounded(panel2, 22)
            }
            val emoji = TextView(this).apply {
                text = p.emoji
                textSize = 92f
                gravity = Gravity.CENTER
            }
            media.addView(emoji, LinearLayout.LayoutParams(-1, -1))
            val mediaLp = FrameLayout.LayoutParams(-1, -1)
            mediaLp.setMargins(dp(16), dp(16), dp(16), dp(16))
            top.addView(media, mediaLp)
            top.bringChildToFront(back)
            top.bringChildToFront(favorite)
        }

        root.addView(top, LinearLayout.LayoutParams(-1, dp(390)))

        val scroll = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(28))
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val title = TextView(this).apply {
            text = p.name
            textSize = 28f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), 0, dp(6))
        }
        body.addView(title)

        if (p.name == "BEEGO Burger") {
            val hit = TextView(this).apply {
                text = "Хіт"
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(Color.BLACK)
                background = rounded(yellow, 20)
            }
            body.addView(hit, LinearLayout.LayoutParams(dp(72), dp(40)))
        }

        val selected = BooleanArray(addOnsFor(p).size)
        var quantity = 1

        val price = TextView(this).apply {
            text = "${p.price} ₴"
            textSize = 26f
            setTextColor(yellow)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), 0, dp(6))
        }
        body.addView(price)

        val desc = TextView(this).apply {
            text = when (p.name) {
                "BEEGO Burger" -> "Соковита яловичина, свіжі овочі, фірмовий соус BEEGO, булочка бріош з львівських пекарень."
                else -> p.description
            }
            textSize = 16f
            setTextColor(muted)
            setPadding(0, dp(2), 0, dp(12))
        }
        body.addView(desc)

        val label = TextView(this).apply {
            text = "Оберіть додатково"
            textSize = 20f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), 0, dp(10))
        }
        body.addView(label)

        fun total(): Int {
            var value = p.price * quantity
            addOnsFor(p).forEachIndexed { i, a -> if (selected[i]) value += a.price * quantity }
            return value
        }

        var addButton: Button? = null

        fun refreshPrice() {
            price.text = "${p.price} ₴"
            addButton?.text = "Додати в кошик   ${total()} ₴"
        }

        addOnsFor(p).forEachIndexed { index, addOn ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), 0, dp(16), 0)
                background = rounded(panel2, 16)
                isClickable = true
                isFocusable = true
            }
            val left = TextView(this).apply {
                text = "+  ${addOn.name}"
                textSize = 16f
                setTextColor(white)
                gravity = Gravity.CENTER_VERTICAL
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            val right = TextView(this).apply {
                text = "+${addOn.price} ₴"
                textSize = 16f
                setTextColor(white)
                gravity = Gravity.CENTER_VERTICAL or Gravity.END
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
                singleLine = true
            }
            row.addView(left, LinearLayout.LayoutParams(0, -1, 1f))
            row.addView(right, LinearLayout.LayoutParams(dp(100), -1))
            row.setOnClickListener {
                selected[index] = !selected[index]
                left.text = (if (selected[index]) "✓  " else "+  ") + addOn.name
                row.background = rounded(if (selected[index]) Color.rgb(55, 60, 60) else panel2, 16)
                refreshPrice()
            }
            val lp = LinearLayout.LayoutParams(-1, dp(56))
            lp.setMargins(0, 0, 0, dp(8))
            body.addView(row, lp)
        }

        val qty = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = rounded(panel2, 16)
        }
        val minus = TextView(this).apply { text = "−"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(white) }
        val number = TextView(this).apply { text = "1"; textSize = 20f; gravity = Gravity.CENTER; setTextColor(white) }
        val plus = TextView(this).apply { text = "+"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(white) }
        minus.setOnClickListener { if (quantity > 1) { quantity--; number.text = quantity.toString(); refreshPrice(); } }
        plus.setOnClickListener { quantity++; number.text = quantity.toString(); refreshPrice() }
        qty.addView(minus, LinearLayout.LayoutParams(dp(58), dp(58)))
        qty.addView(number, LinearLayout.LayoutParams(dp(58), dp(58)))
        qty.addView(plus, LinearLayout.LayoutParams(dp(58), dp(58)))
        val qtyLp = LinearLayout.LayoutParams(-2, dp(58)); qtyLp.gravity = Gravity.CENTER; qtyLp.setMargins(0, dp(10), 0, dp(14))
        body.addView(qty, qtyLp)

        addButton = Button(this).apply {
            text = "Додати в кошик   ${total()} ₴"
            textSize = 17f
            setTextColor(Color.BLACK)
            background = rounded(yellow, 18)
            isAllCaps = false
            setOnClickListener {
                cart[p.name] = (cart[p.name] ?: 0) + quantity
                showMenu()
            }
        }
        body.addView(addButton!!, LinearLayout.LayoutParams(-1, dp(62)))

        setContentView(root)
        hideSystemBars()
        root.alpha = 0f
        root.animate().alpha(1f).setDuration(140L).start()
    }

    private fun secondaryButton(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = 15f
            setTextColor(white)
            background = rounded(panel2, 16)
            isAllCaps = false
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, dp(52)); lp.setMargins(0, dp(6), 0, dp(6))
        content.addView(b, lp)
    }

    private fun cartCount(): Int = cart.values.sum()

    private fun showCart() {
        shell("Кошик")
        heading("Кошик", 29f)
        if (cart.isEmpty()) {
            body("🛒 Кошик порожній.", 18f, white)
            body("Обери страви в меню — вони з'являться тут.")
            secondaryButton("Перейти до меню") { showMenu() }
            return
        }

        var subtotal = 0
        cart.entries.toList().forEach { entry ->
            val p = products.firstOrNull { it.name == entry.key } ?: return@forEach
            val qty = entry.value
            subtotal += p.price * qty
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = rounded(panel, 16)
            }
            val name = TextView(this).apply {
                text = "${p.emoji}  ${p.name}\n$qty × ${p.price} ₴"
                textSize = 15f
                setTextColor(white)
            }
            row.addView(name, LinearLayout.LayoutParams(0, dp(64), 1f))
            val minus = Button(this).apply {
                text = "−"; textSize = 20f; setTextColor(white); background = rounded(panel2, 12)
                setOnClickListener {
                    if (qty <= 1) cart.remove(p.name) else cart[p.name] = qty - 1
                    showCart()
                }
            }
            row.addView(minus, LinearLayout.LayoutParams(dp(48), dp(48)))
            val plus = Button(this).apply {
                text = "+"; textSize = 20f; setTextColor(Color.BLACK); background = rounded(yellow, 12)
                setOnClickListener { cart[p.name] = qty + 1; showCart() }
            }
            val plusLp = LinearLayout.LayoutParams(dp(48), dp(48)); plusLp.setMargins(dp(6), 0, 0, 0)
            row.addView(plus, plusLp)
            val lp = LinearLayout.LayoutParams(-1, dp(84)); lp.setMargins(0, 0, 0, dp(8))
            content.addView(row, lp)
        }

        sectionLabel("Підсумок")
        body("Сума страв: $subtotal ₴", 16f, white)
        body("Доставка BEEGO: 29 ₴", 16f, white)
        heading("Разом: ${subtotal + 29} ₴", 24f)
        val order = Button(this).apply {
            text = "Оформити замовлення"
            textSize = 17f
            setTextColor(Color.BLACK)
            background = rounded(yellow, 17)
            isAllCaps = false
            setOnClickListener {
                if (selectedHub == null) showHubs() else showCheckout()
            }
        }
        content.addView(order, LinearLayout.LayoutParams(-1, dp(58)))
        secondaryButton("← Продовжити покупки") { showMenu() }
    }

    private fun showSplash() {
        // The splash artwork already contains the language control and the
        // yellow START button. Do not draw them a second time. We only place
        // transparent hit areas over the artwork so the controls stay clickable.
        val root = android.widget.FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val bgImage = ImageView(this).apply {
            val source = android.graphics.BitmapFactory.decodeStream(assets.open("splash_bg.jpg"))
            // Remove only the fake status-bar artwork baked into the image.
            // Keep the rest of the artwork intact and preserve its proportions.
            val topCrop = (source.height * 0.054f).toInt()
            val h = source.height - topCrop
            setImageBitmap(android.graphics.Bitmap.createBitmap(source, 0, topCrop, source.width, h))
            // Preserve the original artwork ratio; never stretch the drone, logo,
            // buildings or text horizontally. The screen is filled by center-crop.
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        val imageLp = android.widget.FrameLayout.LayoutParams(-1, -1)
        // Fill the real fullscreen viewport with the cropped artwork.
        root.addView(bgImage, imageLp)

        // The language selector is part of the artwork, exactly as in the reference.
        // Use an invisible hit area so there is no second visible UA control.
        val languageHit = View(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
            setOnClickListener { showLanguagePopup(this) }
        }
        val langLp = android.widget.FrameLayout.LayoutParams(dp(190), dp(62), Gravity.TOP or Gravity.END)
        langLp.setMargins(0, dp(8), dp(8), 0)
        root.addView(languageHit, langLp)

        // Real transparent START hit target. It is calculated from the actual
        // screen height, matching the baked-in button while remaining reliable
        // on different Android phone sizes.
        val startHit = View(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
            setOnClickListener {
                if (!isEnabled) return@setOnClickListener
                isEnabled = false
                showHome()
            }
        }
        val startLp = android.widget.FrameLayout.LayoutParams(-1, dp(112))
        startLp.setMargins(dp(38), 0, dp(38), 0)
        root.addView(startHit, startLp)

        setContentView(root)
        hideSystemBars()

        root.post {
            val lp = startHit.layoutParams as android.widget.FrameLayout.LayoutParams
            lp.topMargin = (root.height * 0.782f).toInt()
            lp.height = (root.height * 0.090f).toInt()
            startHit.layoutParams = lp
        }
    }

    private fun showLanguagePopup(anchor: View) {
        val popup = android.widget.PopupWindow(this).apply {
            width = dp(260)
            height = ViewGroup.LayoutParams.WRAP_CONTENT
            isFocusable = true
            elevation = dp(10).toFloat()
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = rounded(panel2, 20)
        }
        val title = TextView(this).apply {
            text = "Мова / Language"
            textSize = 18f
            setTextColor(white)
            setPadding(0, dp(4), 0, dp(8))
        }
        box.addView(title)
        listOf("✓  🇺🇦  Українська", "🇬🇧  English", "🇵🇱  Polski").forEach { lang ->
            val b = Button(this).apply {
                text = lang
                textSize = 16f
                setTextColor(if (lang.startsWith("✓")) yellow else white)
                background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
                isAllCaps = false
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setOnClickListener {
                    bodyToast("Обрано: ${lang.replace("✓  ", "")}")
                    popup.dismiss()
                }
            }
            box.addView(b, LinearLayout.LayoutParams(dp(220), dp(50)))
        }
        popup.contentView = box
        popup.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        popup.showAsDropDown(anchor, -dp(140), dp(8))
    }

    private fun showHome() {
        shell("Львів")

        val location = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, dp(6))
        }
        val pin = TextView(this).apply { text = "📍"; textSize = 27f }
        location.addView(pin, LinearLayout.LayoutParams(dp(42), dp(48)))
        val locText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val city = TextView(this).apply {
            text = "Львів"
            textSize = 21f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        val address = TextView(this).apply {
            text = "Вул. Стрийська, 45 ⌄"
            textSize = 14f
            setTextColor(muted)
        }
        locText.addView(city)
        locText.addView(address)
        location.addView(locText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val bell = Button(this).apply {
            text = "🔔"
            textSize = 20f
            setTextColor(white)
            background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            setOnClickListener { bodyToast("Нових сповіщень немає") }
        }
        location.addView(bell, LinearLayout.LayoutParams(dp(54), dp(50)))
        content.addView(location)

        val hero = ImageView(this).apply {
            setImageBitmap(android.graphics.BitmapFactory.decodeStream(assets.open("home_banner.png")))
            // Preserve the source aspect ratio. The view width remains the same,
            // while Android calculates the correct height; nothing is stretched
            // and no part of the banner is cropped.
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            background = rounded(panel, 22)
            clipToOutline = true
            setOnClickListener { showMenu() }
        }
        val heroLp = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
        heroLp.setMargins(0, 0, 0, dp(12))
        content.addView(hero, heroLp)

        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val rows = listOf(
            listOf("🍔" to "Бургери", "🥣" to "Боулі", "🍕" to "Піца", "🍰" to "Десерти"),
            listOf("☕" to "Напої", "🌿" to "Healthy", "🔥" to "Новинки", "%" to "Акції")
        )
        rows.forEach { rowData ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowData.forEach { pair ->
                val b = Button(this).apply {
                    text = "${pair.first}\n${pair.second}"
                    textSize = 11.5f
                    setTextColor(white)
                    background = rounded(panel, 17)
                    isAllCaps = false
                    setOnClickListener {
                        selectedCategory = when (pair.second) {
                            "Бургери" -> "Бургери"
                            "Піца" -> "Піца"
                            "Десерти" -> "Десерти"
                            "Напої" -> "Напої"
                            else -> "Усе"
                        }
                        showMenu()
                    }
                }
                val lp = LinearLayout.LayoutParams(0, dp(78), 1f)
                lp.setMargins(0, 0, dp(6), dp(6))
                row.addView(b, lp)
            }
            grid.addView(row)
        }
        content.addView(grid)

        val popularHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val popular = TextView(this).apply {
            text = "Популярне"
            textSize = 23f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        popularHeader.addView(popular, LinearLayout.LayoutParams(0, dp(50), 1f))
        val all = Button(this).apply {
            text = "Дивитись всі  ›"
            textSize = 13f
            setTextColor(white)
            background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            isAllCaps = false
            setOnClickListener { showMenu() }
        }
        popularHeader.addView(all, LinearLayout.LayoutParams(dp(132), dp(50)))
        content.addView(popularHeader)

        val productsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val homeProducts = listOf(products[0] to "product_burger.png", products[6] to "product_bowl.png")
        homeProducts.forEach { (p, assetName) ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(panel, 18)
                setPadding(dp(5), dp(5), dp(5), dp(6))
                setOnClickListener { showProduct(p) }
            }
            val image = ImageView(this).apply {
                setImageBitmap(android.graphics.BitmapFactory.decodeStream(assets.open(assetName)))
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = rounded(panel2, 14)
                clipToOutline = true
            }
            card.addView(image, LinearLayout.LayoutParams(-1, dp(105)))
            val name = TextView(this).apply {
                text = p.name
                textSize = 14f
                setTextColor(white)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(6), dp(5), dp(4), 0)
                maxLines = 1
            }
            card.addView(name)
            val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val price = TextView(this).apply {
                text = "${p.price} ₴"
                textSize = 15f
                setTextColor(yellow)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(6), 0, 0, 0)
            }
            bottom.addView(price, LinearLayout.LayoutParams(0, dp(42), 1f))
            val add = Button(this).apply {
                text = "+"
                textSize = 22f
                setTextColor(Color.BLACK)
                background = rounded(yellow, 13)
                setOnClickListener {
                    cart[p.name] = (cart[p.name] ?: 0) + 1
                    showHome()
                }
            }
            bottom.addView(add, LinearLayout.LayoutParams(dp(50), dp(50)))
            card.addView(bottom)
            val lp = LinearLayout.LayoutParams(0, dp(190), 1f)
            lp.setMargins(0, 0, dp(8), 0)
            productsRow.addView(card, lp)
        }
        content.addView(productsRow)
    }

    private fun bodyToast(message: String) {
        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun paymentButton(method: String) {
        val selected = paymentMethod == method
        val label = if (selected) "✓ $method" else method
        secondaryButton(label) {
            paymentMethod = method
            if (selectedHub != null && cart.isNotEmpty()) {
                showCheckout()
            } else {
                showProfileSection("Способи оплати", "Керуй доступними способами оплати замовлень.")
            }
        }
    }

    private fun showCheckout() {
        shell("Оформлення")
        heading("Оформлення замовлення", 27f)
        val hub = selectedHub ?: "Не обрано"
        body("📍 Точка отримання", 13f, yellow)
        secondaryButton("$hub  ›") { showHubs() }

        sectionLabel("Оплата")
        paymentButton("💳 Банківська картка")
        paymentButton("💵 Готівка при отриманні")
        paymentButton("🟢 Google Pay")
        paymentButton(" Apple Pay")
        body("Обрано: $paymentMethod", 14f, yellow)

        val subtotal = cart.entries.sumOf { entry ->
            val product = products.firstOrNull { it.name == entry.key }
            (product?.price ?: 0) * entry.value
        }
        body("Сума страв: $subtotal ₴", 16f, white)
        body("Доставка BEEGO: 29 ₴", 16f, white)
        heading("Разом: ${subtotal + 29} ₴", 24f)

        val confirm = Button(this).apply {
            text = "Підтвердити замовлення"
            textSize = 17f
            setTextColor(Color.BLACK)
            background = rounded(yellow, 17)
            isAllCaps = false
            setOnClickListener {
                orderConfirmed = true
                trackingStage = 1
                showTrack()
            }
        }
        content.addView(confirm, LinearLayout.LayoutParams(-1, dp(58)))
        secondaryButton("← До кошика") { showCart() }
    }

    private fun showTrack() {
        shell("Доставка")
        heading(if (orderConfirmed) "🚁 BEEGO у польоті" else "🚁 Доставка", 25f)
        val hub = selectedHub ?: "HUB не обрано"
        body("📍 Точка отримання: $hub", 16f, white)

        sectionLabel("Статус замовлення")
        val stages = listOf(
            "✓ Замовлення прийнято",
            "✓ Ресторан готує замовлення",
            "🚁 Дрон прямує до HUB",
            "📍 Замовлення прибуло в HUB"
        )
        stages.forEachIndexed { index, stage ->
            val active = index <= trackingStage
            body(if (active) stage else "○ ${stage.removePrefix("✓ ").removePrefix("🚁 ").removePrefix("📍 ")}", 16f, if (active) yellow else muted)
        }

        val time = when (trackingStage) {
            0 -> "Підтвердь замовлення, щоб запустити доставку."
            1 -> "Ресторан готує замовлення."
            2 -> "Дрон вже летить до обраного HUB."
            else -> "Замовлення готове до отримання в HUB."
        }
        body(time, 15f, white)

        if (orderConfirmed && trackingStage < 3) {
            val next = Button(this).apply {
                text = if (trackingStage == 1) "🚁 Дрон вилетів" else "Оновити статус"
                textSize = 17f
                setTextColor(Color.BLACK)
                background = rounded(yellow, 17)
                isAllCaps = false
                setOnClickListener {
                    trackingStage = (trackingStage + 1).coerceAtMost(3)
                    showTrack()
                }
            }
            content.addView(next, LinearLayout.LayoutParams(-1, dp(58)))
        } else if (orderConfirmed) {
            body("🎉 Замовлення прибуло. Можна забирати в HUB.", 17f, yellow)
        }

        secondaryButton("← Повернутися до меню") { showMenu() }
    }

    private fun showHubs() {
        shell("BEEGO HUB")
        heading("BEEGO HUB")
        body("Обери точку отримання замовлення.", 15f)
        val hubs = listOf(
            "Площа Ринок — HUB 01",
            "Сихів — HUB 02",
            "Наукова — HUB 03",
            "Левандівка — HUB 04"
        )
        hubs.forEach { hub ->
            secondaryButton("📍 $hub") { showHubDetails(hub) }
        }
        body("Безпечні точки прийому та видачі замовлень.")
    }

    private fun showHubDetails(hub: String) {
        shell("BEEGO HUB")
        heading(hub, 25f)
        body("🟢 HUB доступний для отримання замовлень.", 16f, white)
        body("🚁 Доставка дроном до точки отримання.", 15f)
        body("⏱ Орієнтовний час: 8–12 хв", 16f, yellow)
        val select = Button(this).apply {
            text = "Обрати цей HUB"
            textSize = 17f
            setTextColor(Color.BLACK)
            background = rounded(yellow, 17)
            isAllCaps = false
            setOnClickListener {
                selectedHub = hub
                trackingStage = 0
                showCart()
            }
        }
        content.addView(select, LinearLayout.LayoutParams(-1, dp(58)))
        secondaryButton("← До списку HUB") { showHubs() }
    }

    private fun showProfile() {
        shell("Профіль")
        heading("👤 Мій профіль")
        body("Керуйте своїми даними та налаштуваннями.", 15f)

        secondaryButton("📦 Історія замовлень  ›") { showProfileSection("Історія замовлень", "Тут будуть усі твої замовлення BEEGO.") }
        secondaryButton("📍 Мої адреси  ›") { showProfileSection("Мої адреси", "Додай HUB-и, які використовуєш найчастіше.") }
        secondaryButton("💳 Способи оплати  ›") { showProfileSection("Способи оплати", "Керуй доступними способами оплати замовлень.") }
        secondaryButton("⭐ BEEGO Plus  ›") { showProfileSection("BEEGO Plus", "Переваги підписки BEEGO Plus та спеціальні умови.") }
    }

    private fun showProfileSection(title: String, description: String) {
        shell("Профіль")
        heading(title, 27f)
        body(description, 16f, white)

        when (title) {
            "Історія замовлень" -> {
                sectionLabel("Замовлення")
                secondaryButton("📦 Замовлення #BEEGO-001") {}
                body("Поки що це демонстраційна історія замовлень.", 14f)
            }
            "Мої адреси" -> {
                sectionLabel("Точки отримання")
                secondaryButton("📍 Площа Ринок — HUB 01") { showHubDetails("Площа Ринок — HUB 01") }
                secondaryButton("📍 Сихів — HUB 02") { showHubDetails("Сихів — HUB 02") }
                secondaryButton("📍 Наукова — HUB 03") { showHubDetails("Наукова — HUB 03") }
                secondaryButton("📍 Левандівка — HUB 04") { showHubDetails("Левандівка — HUB 04") }
            }
            "Способи оплати" -> {
                sectionLabel("Оплата")
                paymentButton("💳 Банківська картка")
                paymentButton("💵 Готівка при отриманні")
                paymentButton("🟢 Google Pay")
                paymentButton(" Apple Pay")
            }
            "BEEGO Plus" -> {
                sectionLabel("Переваги")
                body("⭐ Пріоритетні можливості BEEGO.", 16f, white)
                body("🚁 Зручне відстеження доставки.", 15f)
                body("🎁 Спеціальні пропозиції для учасників.", 15f)
            }
        }
        secondaryButton("← Назад до профілю") { showProfile() }
    }
}
