package com.beego.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.WindowInsets
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.osmdroid.config.Configuration
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.MapTileIndex

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 10, 10)
    private val panel = Color.rgb(25, 28, 28)
    private val panel2 = Color.rgb(33, 36, 36)
    private val yellow = Color.rgb(255, 193, 7)
    private val white = Color.WHITE
    private val muted = Color.rgb(180, 184, 187)
    private val green = Color.rgb(92, 200, 120)

    private data class Product(
        val name: String,
        val category: String,
        val price: Int,
        val emoji: String,
        val description: String
    )

    private data class AddOn(
        val name: String,
        val price: Int
    )

    private val products = listOf(
        Product("BEEGO Burger", "Бургери", 189, "🍔", "Соковита яловичина, сир, салат, томат і фірмовий соус."),
        Product("Chicken Crispy", "Бургери", 179, "🍗", "Хрустка курка, салат, сир та легкий фірмовий соус."),
        Product("City Pizza", "Піца", 160, "🍕", "Моцарела, томати, пепероні та базилік на тонкому тісті."),
        Product("Four Cheese", "Піца", 179, "🧀", "Моцарела, чедер, дорблю та пармезан."),
        Product("Crispy Fries", "Закуски", 79, "🍟", "Хрустка картопля з сіллю та фірмовим соусом."),
        Product("Chicken Wings", "Закуски", 129, "🍗", "Курячі крильця з хрусткою скоринкою та соусом."),
        Product("Fresh Salad", "Healthy", 60, "🥗", "Курка-гриль, авокадо, томати, зелень та рис."),
        Product("Cola Zero", "Напої", 49, "🥤", "Охолоджений напій без цукру."),
        Product("Лимонад BEEGO", "Напої", 69, "🍋", "Домашній лимонад з лимоном, м’ятою та льодом."),
        Product("Cheesecake", "Десерти", 89, "🍰", "Ніжний вершковий чизкейк з ягідним соусом.")
    )

    private val cart = linkedMapOf<String, Int>()
    private lateinit var content: LinearLayout
    private lateinit var screenHost: FrameLayout
    private var currentScreen: View? = null
    private var selectedCategory = "Усе"
    private var selectedHub: String? = null
    private var orderConfirmed = false
    private var trackingStage = 0
    private var paymentMethod = " Apple Pay"
    private var deliveryMethod = "drone"
    private var trackingMap: MapView? = null
    private var reviewInput: EditText? = null
    private var reviewPhotoPreview: ImageView? = null
    private var reviewPhotoUri: Uri? = null
    private val prefs by lazy { getSharedPreferences("beego_profile", MODE_PRIVATE) }
    private var profileName: String = ""
    private var profilePhone: String = ""
    private var profileAvatarUri: Uri? = null
    private var cardLast4: String = ""
    private var cardExpiry: String = ""
    private var cardHolder: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Initialize osmdroid before creating MapView so online map tiles
        // have a persistent cache/configuration and can be loaded reliably.
        val osmdroidConfig = Configuration.getInstance()
        osmdroidConfig.load(
            this,
            getSharedPreferences("osmdroid", MODE_PRIVATE)
        )
        // Use a fresh private cache so an old/corrupt osmdroid SQLite cache
        // cannot leave the map stuck on the gray grid.
        osmdroidConfig.osmdroidBasePath = java.io.File(filesDir, "osmdroid_v2")
        osmdroidConfig.osmdroidTileCache = java.io.File(
            osmdroidConfig.osmdroidBasePath,
            "tiles"
        )
        osmdroidConfig.osmdroidBasePath.mkdirs()
        osmdroidConfig.osmdroidTileCache.mkdirs()
        // OSM requires a meaningful User-Agent for tile requests.
        osmdroidConfig.userAgentValue = "com.beego.app/19 (BEEGO Android)"
        osmdroidConfig.setMapTileDownloaderFollowRedirects(true)

        // True fullscreen for modern Android, including Android 15/16.
        // The bars are hidden again when the window regains focus, without
        // installing an Insets listener that could cause a focus loop.
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        hideSystemBars()
        screenHost = FrameLayout(this).apply {
            setBackgroundColor(bg)
            clipChildren = false
            clipToPadding = false
        }
        setContentView(screenHost)
        profileName = prefs.getString("name", "") ?: ""
        profilePhone = prefs.getString("phone", "") ?: ""
        cardLast4 = prefs.getString("card_last4", "") ?: ""
        cardExpiry = prefs.getString("card_expiry", "") ?: ""
        cardHolder = prefs.getString("card_holder", "") ?: ""
        prefs.getString("avatar", null)?.let { profileAvatarUri = Uri.parse(it) }
        showHome()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return

        val uri = data?.data ?: return
        when (requestCode) {
            4201 -> {
                // Profile/account avatar.
                profileAvatarUri = uri
                prefs.edit().putString("avatar", uri.toString()).apply()
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) { }
                showProfile()
            }
            4101 -> {
                // Review photo.
                reviewPhotoUri = uri
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) { }
                reviewPhotoPreview?.apply {
                    setImageURI(uri)
                    visibility = View.VISIBLE
                }
                bodyToast("Фото додано 📷")
            }
        }
    }

    private fun hideSystemBars() {
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.systemBars())
                controller.systemBarsBehavior =
                    android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onResume() {
        super.onResume()
        trackingMap?.onResume()
    }

    override fun onPause() {
        trackingMap?.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        trackingMap?.onDetach()
        trackingMap = null
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun loadMenuCardBitmap(asset: String): android.graphics.Bitmap {
        return android.graphics.BitmapFactory.decodeStream(assets.open(asset))
    }

    private fun cheesecakeView(): View = object : View(this) {
        private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private val path = android.graphics.Path()

        override fun onDraw(c: android.graphics.Canvas) {
            super.onDraw(c)
            val w = width.toFloat()
            val h = height.toFloat()
            val cx = w / 2f
            val baseY = h * 0.68f

            // soft plate/shadow
            paint.color = Color.argb(80, 0, 0, 0)
            c.drawOval(cx - w*0.34f, baseY + h*0.02f, cx + w*0.34f, baseY + h*0.14f, paint)

            // golden biscuit base
            paint.color = Color.rgb(190, 125, 63)
            c.drawRoundRect(cx - w*0.30f, baseY - h*0.08f, cx + w*0.30f, baseY + h*0.10f,
                dp(10).toFloat(), dp(10).toFloat(), paint)

            // creamy cheesecake layer
            paint.color = Color.rgb(255, 239, 211)
            c.drawRoundRect(cx - w*0.30f, baseY - h*0.25f, cx + w*0.30f, baseY + h*0.02f,
                dp(12).toFloat(), dp(12).toFloat(), paint)

            // baked top
            paint.color = Color.rgb(232, 198, 143)
            c.drawRoundRect(cx - w*0.30f, baseY - h*0.25f, cx + w*0.30f, baseY - h*0.16f,
                dp(10).toFloat(), dp(10).toFloat(), paint)

            // berry glaze
            paint.color = Color.rgb(156, 24, 50)
            path.reset()
            path.moveTo(cx - w*0.27f, baseY - h*0.17f)
            path.cubicTo(cx - w*0.12f, baseY - h*0.23f, cx + w*0.10f, baseY - h*0.11f, cx + w*0.27f, baseY - h*0.19f)
            path.lineTo(cx + w*0.27f, baseY - h*0.10f)
            path.cubicTo(cx + w*0.10f, baseY - h*0.02f, cx - w*0.12f, baseY - h*0.13f, cx - w*0.27f, baseY - h*0.08f)
            path.close()
            c.drawPath(path, paint)

            // strawberries / berries
            paint.color = Color.rgb(222, 48, 67)
            c.drawCircle(cx + w*0.13f, baseY - h*0.28f, w*0.055f, paint)
            c.drawCircle(cx + w*0.22f, baseY - h*0.22f, w*0.045f, paint)
            c.drawCircle(cx + w*0.04f, baseY - h*0.24f, w*0.042f, paint)

            // mint leaves
            paint.color = Color.rgb(66, 150, 76)
            c.drawOval(cx + w*0.07f, baseY - h*0.35f, cx + w*0.15f, baseY - h*0.25f, paint)
            c.drawOval(cx + w*0.16f, baseY - h*0.34f, cx + w*0.25f, baseY - h*0.25f, paint)
        }
    }

    private fun rounded(color: Int, radius: Int = 18): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun shell(title: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(10), dp(12), dp(8))
        }

        val logo = TextView(this).apply {
            text = "🐝  BEEGO"
            textSize = 23f
            setTextColor(yellow)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(logo, LinearLayout.LayoutParams(0, dp(54), 1f))

        val cartButton = Button(this).apply {
            text = if (cartCount() > 0) "🛒 ${cartCount()}" else "🛒"
            textSize = 14f
            setTextColor(white)
            background = rounded(panel2, 16)
            isAllCaps = false
            setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { showCart() }
        }
        header.addView(cartButton, LinearLayout.LayoutParams(dp(82), dp(48)))
        root.addView(header)

        val titleView = TextView(this).apply {
            text = title
            textSize = 15f
            setTextColor(muted)
            setPadding(dp(18), 0, dp(18), dp(6))
        }
        root.addView(titleView)

        val scroll = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(4), dp(18), dp(92))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(panel)
            setPadding(0, dp(4), 0, dp(4))
        }
        navButton(nav, "⌂", "Головна") { showHome() }
        navButton(nav, "🍔", "Меню") { showMenu() }
        navButton(nav, "🚁", "Дрон") { showTrack() }
        navButton(nav, "📍", "HUB") { showHubs() }
        navButton(nav, "👤", "Профіль") { showProfile() }
        root.addView(nav, LinearLayout.LayoutParams(-1, dp(70)))

        present(root)
    }

    private fun navButton(parent: LinearLayout, icon: String, label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = "$icon\n$label"
            textSize = 10f
            setTextColor(white)
            background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            isAllCaps = false
            setOnClickListener { action() }
        }
        parent.addView(b, LinearLayout.LayoutParams(0, dp(62), 1f))
    }

    private fun heading(value: String, size: Float = 29f) {
        val t = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), 0, dp(8))
        }
        content.addView(t)
    }

    private fun body(value: String, size: Float = 16f, color: Int = muted) {
        val t = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            setPadding(0, dp(2), 0, dp(8))
        }
        content.addView(t)
    }

    private fun sectionLabel(value: String) {
        val t = TextView(this).apply {
            text = value.uppercase()
            textSize = 12f
            setTextColor(yellow)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(18), 0, dp(8))
        }
        content.addView(t)
    }

    private fun categoryBar() {
        val hsv = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(2), dp(4), dp(4))
        }
        val cats = listOf("Усе", "Бургери", "Піца", "Закуски", "Напої", "Healthy", "Десерти")
        cats.forEach { cat ->
            val b = TextView(this).apply {
                text = cat
                textSize = 14f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(if (cat == selectedCategory) Color.BLACK else white)
                background = rounded(if (cat == selectedCategory) yellow else panel2, 24)
                setPadding(dp(20), 0, dp(20), 0)
                setOnClickListener {
                    selectedCategory = cat
                    showMenu()
                }
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46))
            lp.setMargins(0, 0, dp(9), 0)
            row.addView(b, lp)
        }
        hsv.addView(row)
        content.addView(hsv, LinearLayout.LayoutParams(-1, dp(54)))
    }

    private fun productAsset(p: Product): String? = when (p.name) {
        "BEEGO Burger" -> "product_burger.png"
        "Chicken Crispy" -> "product_chicken_crispy.png"
        "City Pizza" -> "product_city_pizza.png"
        "Four Cheese" -> "product_four_cheese.png"
        "Crispy Fries" -> "product_fries.png"
        "Chicken Wings" -> "product_wings.png"
        "Fresh Salad" -> "product_bowl.png"
        "Cola Zero" -> "product_cola.png"
        "Лимонад BEEGO" -> "product_lemonade.png"
        "Cheesecake" -> "product_cheesecake.jpg"
        else -> null
    }

    private fun productCard(p: Product) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            isClickable = true
            isFocusable = true
            background = rounded(panel, 22)
            setPadding(dp(7), dp(7), dp(7), dp(7))
            setOnClickListener { showProduct(p) }
        }

        val media = FrameLayout(this).apply {
            background = rounded(panel2, 18)
            clipToOutline = true
        }
        val asset = productAsset(p)
        if (asset != null) {
            val image = ImageView(this).apply {
                setImageBitmap(loadMenuCardBitmap(asset))
                scaleType = ImageView.ScaleType.CENTER_CROP
                clipToOutline = true
            }
            media.addView(image, FrameLayout.LayoutParams(-1, -1))
        } else {
            if (p.name == "Cheesecake") {
                media.addView(cheesecakeView(), FrameLayout.LayoutParams(-1, -1))
            } else {
                val icon = TextView(this).apply {
                    text = p.emoji
                    textSize = 48f
                    gravity = Gravity.CENTER
                    setTextColor(white)
                }
                media.addView(icon, FrameLayout.LayoutParams(-1, -1))
            }
        }

        val hit = TextView(this).apply {
            text = if (p.name == "BEEGO Burger") "ХІТ" else ""
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            background = rounded(yellow, 12)
            if (text.isEmpty()) visibility = View.GONE
        }
        val hitLp = FrameLayout.LayoutParams(dp(48), dp(28), Gravity.TOP or Gravity.START)
        hitLp.setMargins(dp(8), dp(8), 0, 0)
        media.addView(hit, hitLp)
        card.addView(media, LinearLayout.LayoutParams(-1, dp(122)))

        val name = TextView(this).apply {
            text = p.name
            textSize = 17f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(dp(4), dp(9), dp(4), 0)
        }
        card.addView(name)

        val desc = TextView(this).apply {
            text = p.description
            textSize = 11.5f
            setTextColor(muted)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(dp(4), dp(2), dp(4), 0)
        }
        card.addView(desc, LinearLayout.LayoutParams(-1, dp(34)))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(4), 0, 0)
        }
        val price = TextView(this).apply {
            text = "${p.price} ₴"
            textSize = 17f
            setTextColor(yellow)
            typeface = Typeface.DEFAULT_BOLD
        }
        bottom.addView(price, LinearLayout.LayoutParams(0, dp(42), 1f))

        val add = Button(this).apply {
            text = "+"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            isAllCaps = false
            minWidth = 0
            minHeight = 0
            setPadding(0, 0, 0, 0)
            tag = "cart_plus"
            background = rounded(yellow, 15)
            elevation = dp(7).toFloat()
            contentDescription = "Додати ${p.name} в кошик"
            isClickable = true
            isFocusable = true
            installSoftPlusPress(this)
            setOnClickListener {
                cart[p.name] = (cart[p.name] ?: 0) + 1
                bodyToast("${p.name} додано в кошик")
                showMenu()
            }
        }
        bottom.addView(add, LinearLayout.LayoutParams(dp(46), dp(42)))
        card.addView(bottom)

        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(dp(0), 0, dp(8), 0)
        currentRow?.addView(card, lp)
    }

    private var currentRow: LinearLayout? = null

    private fun showMenu() {
        shell("Меню • Львів")

        // Keep the reference layout while restoring the horizontal category filter.
        // The category row stays in normal vertical flow so it cannot overlap the grid.
        categoryBar()
        sectionLabel(if (selectedCategory == "Усе") "Популярне" else selectedCategory)

        val list = if (selectedCategory == "Усе") products else products.filter { it.category == selectedCategory }
        var index = 0
        while (index < list.size) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.TOP
            }
            currentRow = row
            productCard(list[index])
            if (index + 1 < list.size) productCard(list[index + 1])
            currentRow = null
            val rowLp = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
            if (index + 2 < list.size) rowLp.setMargins(0, 0, 0, dp(10))
            content.addView(row, rowLp)
            index += 2
        }

        val note = TextView(this).apply {
            text = "🚁 Доставка дроном доступна в зонах покриття BEEGO."
            textSize = 13f
            setTextColor(muted)
            setPadding(0, dp(8), 0, dp(10))
        }
        content.addView(note)
    }

    private fun addOnsFor(p: Product): List<AddOn> = when (p.name) {
        "BEEGO Burger" -> listOf(AddOn("Сир чеддер", 20), AddOn("Бекон", 30), AddOn("Подвійна котлета", 50))
        "Chicken Crispy" -> listOf(AddOn("Сир чеддер", 20), AddOn("Бекон", 25), AddOn("Гострий соус", 15))
        "City Pizza" -> listOf(AddOn("Додатковий сир", 25), AddOn("Пепероні", 30), AddOn("Гриби", 20))
        "Four Cheese" -> listOf(AddOn("Додатковий чеддер", 20), AddOn("Дорблю", 25), AddOn("Пармезан", 20))
        "Crispy Fries" -> listOf(AddOn("Сирний соус", 15), AddOn("Бекон", 25), AddOn("Халапеньйо", 15))
        "Chicken Wings" -> listOf(AddOn("Гострий соус", 15), AddOn("Сирний соус", 15), AddOn("Додаткова порція", 35))
        "Fresh Salad" -> listOf(AddOn("М'ята", 10), AddOn("Лимон", 10), AddOn("Подвійний об'єм", 25))
        "Cola Zero" -> listOf(AddOn("Лід", 0), AddOn("Лимон", 10), AddOn("Подвійний об'єм", 20))
        "Лимонад BEEGO" -> listOf(AddOn("Лід", 0), AddOn("М’ята", 10), AddOn("Додатковий лимон", 10))
        "Cheesecake" -> listOf(AddOn("Ягідний соус", 15), AddOn("Полуниця", 20), AddOn("Шоколад", 20))
        else -> listOf(AddOn("Додатковий соус", 15), AddOn("Сир", 20), AddOn("Подвійна порція", 35))
    }

    private fun showProduct(p: Product) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val top = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }

        val back = TextView(this).apply {
            text = "‹"
            textSize = 48f
            setTextColor(white)
            gravity = Gravity.CENTER
            setOnClickListener { showMenu() }
        }
        val backLp = FrameLayout.LayoutParams(dp(60), dp(60), Gravity.TOP or Gravity.START)
        backLp.setMargins(dp(8), dp(8), 0, 0)
        top.addView(back, backLp)

        val favorite = TextView(this).apply {
            text = "♡"
            textSize = 38f
            setTextColor(white)
            gravity = Gravity.CENTER
            setOnClickListener {
                text = if (text == "♡") "♥" else "♡"
            }
        }
        val favLp = FrameLayout.LayoutParams(dp(60), dp(60), Gravity.TOP or Gravity.END)
        favLp.setMargins(0, dp(8), dp(8), 0)
        top.addView(favorite, favLp)

        val asset = productAsset(p)
        if (asset != null) {
            val image = ImageView(this).apply {
                val source = android.graphics.BitmapFactory.decodeStream(assets.open(asset))
                setImageBitmap(source)
                scaleType = ImageView.ScaleType.CENTER_CROP
                contentDescription = p.name
            }
            val imageLp = FrameLayout.LayoutParams(-1, -1)
            top.addView(image, imageLp)
            top.bringChildToFront(back)
            top.bringChildToFront(favorite)
        } else {
            val media = LinearLayout(this).apply {
                gravity = Gravity.CENTER
                background = rounded(panel2, 22)
            }
            val emoji = TextView(this).apply {
                text = p.emoji
                textSize = 92f
                gravity = Gravity.CENTER
            }
            media.addView(emoji, LinearLayout.LayoutParams(-1, -1))
            val mediaLp = FrameLayout.LayoutParams(-1, -1)
            mediaLp.setMargins(dp(16), dp(16), dp(16), dp(16))
            top.addView(media, mediaLp)
            top.bringChildToFront(back)
            top.bringChildToFront(favorite)
        }

        root.addView(top, LinearLayout.LayoutParams(-1, dp(320)))

        val scroll = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(28))
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val title = TextView(this).apply {
            text = p.name
            textSize = 26f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), 0, dp(6))
        }
        body.addView(title)

        if (p.name == "BEEGO Burger") {
            val hit = TextView(this).apply {
                text = "Хіт"
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(Color.BLACK)
                background = rounded(yellow, 20)
            }
            body.addView(hit, LinearLayout.LayoutParams(dp(72), dp(40)))
        }

        val selected = BooleanArray(addOnsFor(p).size)
        var quantity = 1

        val price = TextView(this).apply {
            text = "${p.price} ₴"
            textSize = 26f
            setTextColor(yellow)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), 0, dp(6))
        }
        body.addView(price)

        val desc = TextView(this).apply {
            text = when (p.name) {
                "BEEGO Burger" -> "Соковита яловичина, свіжі овочі, фірмовий соус BEEGO, булочка бріош з львівських пекарень."
                else -> p.description
            }
            textSize = 16f
            setTextColor(muted)
            setPadding(0, dp(2), 0, dp(12))
        }
        body.addView(desc)

        val label = TextView(this).apply {
            text = "Оберіть додатково"
            textSize = 20f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), 0, dp(10))
        }
        body.addView(label)

        fun total(): Int {
            var value = p.price * quantity
            addOnsFor(p).forEachIndexed { i, a -> if (selected[i]) value += a.price * quantity }
            return value
        }

        var addButton: Button? = null

        fun refreshPrice() {
            price.text = "${p.price} ₴"
            addButton?.text = "Додати в кошик   ${total()} ₴"
        }

        addOnsFor(p).forEachIndexed { index, addOn ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), 0, dp(16), 0)
                background = rounded(panel2, 16)
                isClickable = true
                isFocusable = true
            }
            val left = TextView(this).apply {
                text = "+  ${addOn.name}"
                textSize = 16f
                setTextColor(white)
                gravity = Gravity.CENTER_VERTICAL
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            val right = TextView(this).apply {
                text = "+${addOn.price} ₴"
                textSize = 16f
                setTextColor(white)
                gravity = Gravity.CENTER_VERTICAL or Gravity.END
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
            }
            row.addView(left, LinearLayout.LayoutParams(0, -1, 1f))
            row.addView(right, LinearLayout.LayoutParams(dp(100), -1))
            row.setOnClickListener {
                selected[index] = !selected[index]
                left.text = (if (selected[index]) "✓  " else "+  ") + addOn.name
                row.background = rounded(if (selected[index]) Color.rgb(55, 60, 60) else panel2, 16)
                refreshPrice()
            }
            val lp = LinearLayout.LayoutParams(-1, dp(56))
            lp.setMargins(0, 0, 0, dp(8))
            body.addView(row, lp)
        }

        val qty = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = rounded(panel2, 16)
        }
        val minus = TextView(this).apply { text = "−"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(white) }
        val number = TextView(this).apply { text = "1"; textSize = 20f; gravity = Gravity.CENTER; setTextColor(white) }
        val plus = TextView(this).apply {
            text = "+"
            textSize = 26f
            gravity = Gravity.CENTER
            setTextColor(white)
            isClickable = true
            isFocusable = true
            contentDescription = "Збільшити кількість"
        }
        minus.setOnClickListener { if (quantity > 1) { quantity--; number.text = quantity.toString(); refreshPrice(); } }
        plus.setOnClickListener { quantity++; number.text = quantity.toString(); refreshPrice() }
        installSoftPlusPress(plus)
        qty.addView(minus, LinearLayout.LayoutParams(dp(58), dp(58)))
        qty.addView(number, LinearLayout.LayoutParams(dp(58), dp(58)))
        qty.addView(plus, LinearLayout.LayoutParams(dp(58), dp(58)))
        val qtyLp = LinearLayout.LayoutParams(-2, dp(58)); qtyLp.gravity = Gravity.CENTER; qtyLp.setMargins(0, dp(10), 0, dp(14))
        body.addView(qty, qtyLp)

        addButton = Button(this).apply {
            text = "Додати в кошик   ${total()} ₴"
            textSize = 17f
            setTextColor(Color.BLACK)
            background = rounded(yellow, 18)
            isAllCaps = false
            setOnClickListener {
                cart[p.name] = (cart[p.name] ?: 0) + quantity
                showMenu()
            }
        }
        body.addView(addButton!!, LinearLayout.LayoutParams(-1, dp(62)))

        present(root)
    }

    private fun secondaryButton(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = 14f
            setTextColor(white)
            background = rounded(panel2, 16)
            isAllCaps = false
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, dp(52)); lp.setMargins(0, dp(6), 0, dp(6))
        content.addView(b, lp)
    }

    private fun cartCount(): Int = cart.values.sum()

    private fun cartShell() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(6))
        }
        val title = TextView(this).apply {
            text = "Кошик"
            textSize = 24f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(50), 1f))
        val clear = TextView(this).apply {
            text = "Очистити"
            textSize = 15f
            setTextColor(white)
            gravity = Gravity.CENTER
            setPadding(dp(8), 0, dp(4), 0)
            visibility = if (cart.isEmpty()) View.GONE else View.VISIBLE
            setOnClickListener {
                cart.clear()
                showCart()
            }
        }
        header.addView(clear, LinearLayout.LayoutParams(dp(90), dp(50)))
        root.addView(header)

        val scroll = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(2), dp(18), dp(22))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(panel)
            setPadding(0, dp(4), 0, dp(4))
        }
        navButton(nav, "⌂", "Головна") { showHome() }
        navButton(nav, "🍔", "Меню") { showMenu() }
        navButton(nav, "🚁", "Дрон") { showTrack() }
        navButton(nav, "📍", "HUB") { showHubs() }
        navButton(nav, "👤", "Профіль") { showProfile() }
        root.addView(nav, LinearLayout.LayoutParams(-1, dp(70)))
        present(root)
    }

    private fun deliveryOption(code: String, icon: String, title: String, subtitle: String) {
        val selected = deliveryMethod == code
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(7), dp(8), dp(7))
            background = rounded(if (selected) Color.rgb(45, 42, 20) else panel2, 16)
            setOnClickListener {
                deliveryMethod = code
                showCart()
            }
        }
        val top = TextView(this).apply {
            text = if (selected) "✓  $icon" else icon
            textSize = 21f
            gravity = Gravity.CENTER
            setTextColor(if (selected) yellow else white)
        }
        card.addView(top, LinearLayout.LayoutParams(-1, dp(27)))
        val t = TextView(this).apply {
            text = title
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        card.addView(t, LinearLayout.LayoutParams(-1, dp(22)))
        val sub = TextView(this).apply {
            text = subtitle
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(muted)
        }
        card.addView(sub, LinearLayout.LayoutParams(-1, dp(18)))
        val lp = LinearLayout.LayoutParams(0, dp(94), 1f)
        lp.setMargins(0, 0, dp(7), 0)
        content.addView(card, lp)
    }

    private fun infoRow(icon: String, title: String, value: String, action: () -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(10), dp(8))
            background = rounded(panel2, 15)
            setOnClickListener { action() }
        }
        val iconView = TextView(this).apply {
            text = icon
            textSize = 19f
            gravity = Gravity.CENTER
            setTextColor(yellow)
        }
        row.addView(iconView, LinearLayout.LayoutParams(dp(34), dp(42)))
        val valueView = TextView(this).apply {
            text = value
            textSize = 13f
            setTextColor(white)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        row.addView(valueView, LinearLayout.LayoutParams(0, dp(42), 1f))
        val change = TextView(this).apply {
            text = "$title  ›"
            textSize = 11f
            setTextColor(yellow)
            gravity = Gravity.CENTER
        }
        row.addView(change, LinearLayout.LayoutParams(dp(70), dp(42)))
        content.addView(row, LinearLayout.LayoutParams(-1, dp(58)))
    }

    private fun showCart() {
        cartShell()
        if (cart.isEmpty()) {
            // Premium empty-cart state: no duplicate heading, clear hierarchy,
            // and a strong CTA so the screen never feels unfinished.
            val emptyWrap = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(18), dp(34), dp(18), dp(26))
                background = rounded(panel2, 24)
            }

            val icon = TextView(this).apply {
                text = "🛒"
                textSize = 50f
                gravity = Gravity.CENTER
                setPadding(0, 0, 0, dp(10))
            }
            emptyWrap.addView(icon, LinearLayout.LayoutParams(-1, dp(78)))

            val emptyTitle = TextView(this).apply {
                text = "Твій кошик поки порожній"
                textSize = 23f
                setTextColor(white)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            }
            emptyWrap.addView(emptyTitle, LinearLayout.LayoutParams(-1, dp(38)))

            val emptyText = TextView(this).apply {
                text = "Додай улюблені страви — і вони з'являться тут.\nЗамовлення можна доставити дроном або забрати самовивозом."
                textSize = 14f
                setTextColor(muted)
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(4), dp(10), dp(18))
                setLineSpacing(0f, 1.12f)
            }
            emptyWrap.addView(emptyText, LinearLayout.LayoutParams(-1, dp(72)))

            val goMenu = Button(this).apply {
                text = "Перейти до меню   →"
                textSize = 16f
                setTextColor(Color.BLACK)
                background = rounded(yellow, 18)
                isAllCaps = false
                setOnClickListener { showMenu() }
            }
            emptyWrap.addView(goMenu, LinearLayout.LayoutParams(-1, dp(58)))

            val hint = TextView(this).apply {
                text = "🍔  🍕  🥗  🍋   Обирай, що смакує"
                textSize = 12f
                setTextColor(Color.rgb(145, 149, 151))
                gravity = Gravity.CENTER
                setPadding(0, dp(16), 0, 0)
            }
            emptyWrap.addView(hint, LinearLayout.LayoutParams(-1, dp(34)))

            val emptyLp = LinearLayout.LayoutParams(-1, dp(294))
            emptyLp.setMargins(0, dp(24), 0, dp(12))
            content.addView(emptyWrap, emptyLp)

            val note = TextView(this).apply {
                text = "Після додавання товарів тут автоматично з'являться кількість, доставка та підсумок замовлення."
                textSize = 12f
                setTextColor(Color.rgb(135, 139, 141))
                gravity = Gravity.CENTER
                setPadding(dp(18), dp(8), dp(18), dp(8))
            }
            content.addView(note, LinearLayout.LayoutParams(-1, dp(52)))
            return
        }

        cart.entries.toList().forEach { entry ->
            val p = products.firstOrNull { it.name == entry.key } ?: return@forEach
            val qty = entry.value
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(2), dp(7), dp(2), dp(7))
            }

            val image = ImageView(this).apply {
                val asset = productAsset(p)
                if (asset != null) setImageBitmap(loadMenuCardBitmap(asset))
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = rounded(panel2, 14)
                clipToOutline = true
            }
            row.addView(image, LinearLayout.LayoutParams(dp(68), dp(68)))

            val details = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), 0, dp(7), 0)
            }
            val name = TextView(this).apply {
                text = p.name
                textSize = 14f
                setTextColor(white)
                typeface = Typeface.DEFAULT_BOLD
            }
            details.addView(name)
            val price = TextView(this).apply {
                text = "${p.price} ₴"
                textSize = 12f
                setTextColor(white)
                setPadding(0, dp(3), 0, 0)
            }
            details.addView(price)
            row.addView(details, LinearLayout.LayoutParams(0, dp(68), 1f))

            val controls = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                background = rounded(panel2, 12)
            }
            val minus = TextView(this).apply {
                text = "−"
                textSize = 17f
                setTextColor(white)
                gravity = Gravity.CENTER
                setOnClickListener {
                    if (qty <= 1) cart.remove(p.name) else cart[p.name] = qty - 1
                    showCart()
                }
            }
            controls.addView(minus, LinearLayout.LayoutParams(dp(30), dp(38)))
            val q = TextView(this).apply {
                text = qty.toString()
                textSize = 13f
                setTextColor(white)
                gravity = Gravity.CENTER
            }
            controls.addView(q, LinearLayout.LayoutParams(dp(28), dp(38)))
            val plus = TextView(this).apply {
                text = "+"
                textSize = 17f
                setTextColor(white)
                gravity = Gravity.CENTER
                isClickable = true
                isFocusable = true
                contentDescription = "Збільшити кількість ${p.name}"
                tag = "cart_plus"
                setOnClickListener { cart[p.name] = qty + 1; showCart() }
                installSoftPlusPress(this)
            }
            controls.addView(plus, LinearLayout.LayoutParams(dp(30), dp(38)))
            row.addView(controls, LinearLayout.LayoutParams(dp(88), dp(38)))

            val lp = LinearLayout.LayoutParams(-1, dp(82))
            lp.setMargins(0, 0, 0, dp(3))
            content.addView(row, lp)
        }

        val addMore = Button(this).apply {
            text = "Додати ще"
            textSize = 14f
            setTextColor(white)
            background = rounded(panel2, 17)
            isAllCaps = false
            setOnClickListener { showMenu() }
        }
        content.addView(addMore, LinearLayout.LayoutParams(-1, dp(50)))

        sectionLabel("Спосіб доставки")
        val deliveryRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, 0)
        }
        content.addView(deliveryRow, LinearLayout.LayoutParams(-1, dp(94)))
        // The cart intentionally offers only BEEGO drone delivery and self-pickup.
        deliveryOptionInRow(deliveryRow, "drone", "🚁", "Дроном", "5–15 хв")
        deliveryOptionInRow(deliveryRow, "pickup", "🛍️", "Самовивіз", "30–45 хв")

        if (deliveryMethod == "drone") {
            sectionLabel("Адреса доставки")
            infoRow("📍", "Змінити", "Вул. Стрийська, 45, Львів") { showProfileSection("Мої адреси", "Обери або додай адресу доставки.") }
        }

        sectionLabel("Спосіб оплати")
        infoRow("💳", "Змінити", paymentMethod) { showCheckout() }

        val subtotal = cart.entries.sumOf { entry ->
            val product = products.firstOrNull { it.name == entry.key }
            (product?.price ?: 0) * entry.value
        }
        val deliveryFee = if (deliveryMethod == "drone") 29 else 0
        val total = subtotal + deliveryFee
        val totalRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, dp(8))
        }
        val totalLabel = TextView(this).apply {
            text = "Разом"
            textSize = 17f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        totalRow.addView(totalLabel, LinearLayout.LayoutParams(0, dp(42), 1f))
        val totalValue = TextView(this).apply {
            text = "$total ₴"
            textSize = 19f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
        }
        totalRow.addView(totalValue, LinearLayout.LayoutParams(dp(100), dp(42)))
        content.addView(totalRow)

        val order = Button(this).apply {
            text = "Оформити замовлення   →"
            textSize = 17f
            setTextColor(Color.BLACK)
            background = rounded(yellow, 20)
            isAllCaps = false
            setOnClickListener {
                if (selectedHub == null && deliveryMethod == "drone") showHubs() else showCheckout()
            }
        }
        content.addView(order, LinearLayout.LayoutParams(-1, dp(60)))
    }

    private fun deliveryOptionInRow(parent: LinearLayout, code: String, icon: String, title: String, subtitle: String) {
        val selected = deliveryMethod == code
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = rounded(if (selected) Color.rgb(45, 42, 20) else panel2, 16)
            setOnClickListener {
                deliveryMethod = code
                showCart()
            }
        }
        val top = TextView(this).apply {
            text = if (selected) "✓  $icon" else icon
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(if (selected) yellow else white)
        }
        card.addView(top, LinearLayout.LayoutParams(-1, dp(28)))
        val t = TextView(this).apply {
            text = title
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        card.addView(t, LinearLayout.LayoutParams(-1, dp(20)))
        val sub = TextView(this).apply {
            text = subtitle
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(muted)
        }
        card.addView(sub, LinearLayout.LayoutParams(-1, dp(17)))
        val lp = LinearLayout.LayoutParams(0, dp(94), 1f)
        lp.setMargins(0, 0, dp(8), 0)
        parent.addView(card, lp)
    }

    private fun showSplash() {
        // The splash artwork already contains the language control and the
        // yellow START button. Do not draw them a second time. We only place
        // transparent hit areas over the artwork so the controls stay clickable.
        val root = android.widget.FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val bgImage = ImageView(this).apply {
            val source = android.graphics.BitmapFactory.decodeStream(assets.open("splash_bg.jpg"))
            // Remove only the fake status-bar artwork baked into the image.
            // Keep the rest of the artwork intact and preserve its proportions.
            val topCrop = (source.height * 0.054f).toInt()
            val h = source.height - topCrop
            setImageBitmap(android.graphics.Bitmap.createBitmap(source, 0, topCrop, source.width, h))
            // Preserve the original artwork ratio; never stretch the drone, logo,
            // buildings or text horizontally. The screen is filled by center-crop.
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        val imageLp = android.widget.FrameLayout.LayoutParams(-1, -1)
        // Fill the real fullscreen viewport with the cropped artwork.
        root.addView(bgImage, imageLp)

        // The language selector is part of the artwork, exactly as in the reference.
        // Use an invisible hit area so there is no second visible UA control.
        val languageHit = View(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
            setOnClickListener { showLanguagePopup(this) }
        }
        val langLp = android.widget.FrameLayout.LayoutParams(dp(190), dp(62), Gravity.TOP or Gravity.END)
        langLp.setMargins(0, dp(8), dp(8), 0)
        root.addView(languageHit, langLp)

        // Real transparent START hit target. It is calculated from the actual
        // screen height, matching the baked-in button while remaining reliable
        // on different Android phone sizes.
        val startHit = View(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
            setOnClickListener {
                if (!isEnabled) return@setOnClickListener
                isEnabled = false
                showHome()
            }
        }
        val startLp = android.widget.FrameLayout.LayoutParams(-1, dp(112))
        startLp.setMargins(dp(38), 0, dp(38), 0)
        root.addView(startHit, startLp)

        present(root)

        root.post {
            val lp = startHit.layoutParams as android.widget.FrameLayout.LayoutParams
            lp.topMargin = (root.height * 0.782f).toInt()
            lp.height = (root.height * 0.090f).toInt()
            startHit.layoutParams = lp
        }
    }

    private fun showLanguagePopup(anchor: View) {
        val popup = android.widget.PopupWindow(this).apply {
            width = dp(260)
            height = ViewGroup.LayoutParams.WRAP_CONTENT
            isFocusable = true
            elevation = dp(10).toFloat()
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = rounded(panel2, 20)
        }
        val title = TextView(this).apply {
            text = "Мова / Language"
            textSize = 18f
            setTextColor(white)
            setPadding(0, dp(4), 0, dp(8))
        }
        box.addView(title)
        listOf("✓  🇺🇦  Українська", "🇬🇧  English", "🇵🇱  Polski").forEach { lang ->
            val b = Button(this).apply {
                text = lang
                textSize = 16f
                setTextColor(if (lang.startsWith("✓")) yellow else white)
                background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
                isAllCaps = false
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setOnClickListener {
                    bodyToast("Обрано: ${lang.replace("✓  ", "")}")
                    popup.dismiss()
                }
            }
            box.addView(b, LinearLayout.LayoutParams(dp(220), dp(50)))
        }
        popup.contentView = box
        popup.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        popup.showAsDropDown(anchor, -dp(140), dp(8))
    }

    private fun showHome() {
        shell("Львів")

        val location = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, dp(6))
        }
        val pin = TextView(this).apply { text = "📍"; textSize = 27f }
        location.addView(pin, LinearLayout.LayoutParams(dp(42), dp(48)))
        val locText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val city = TextView(this).apply {
            text = "Львів"
            textSize = 21f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        val address = TextView(this).apply {
            text = "Вул. Стрийська, 45 ⌄"
            textSize = 12f
            setTextColor(muted)
        }
        locText.addView(city)
        locText.addView(address)
        location.addView(locText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val bell = Button(this).apply {
            text = "🔔"
            textSize = 20f
            setTextColor(white)
            background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            setOnClickListener { bodyToast("Нових сповіщень немає") }
        }
        location.addView(bell, LinearLayout.LayoutParams(dp(54), dp(50)))
        content.addView(location)

        val hero = ImageView(this).apply {
            setImageBitmap(android.graphics.BitmapFactory.decodeStream(assets.open("home_banner.png")))
            // Preserve the source aspect ratio. The view width remains the same,
            // while Android calculates the correct height; nothing is stretched
            // and no part of the banner is cropped.
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            background = rounded(panel, 22)
            clipToOutline = true
            setOnClickListener { showMenu() }
        }
        val heroLp = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
        heroLp.setMargins(0, 0, 0, dp(12))
        content.addView(hero, heroLp)

        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val rows = listOf(
            listOf("🍔" to "Бургери", "🥣" to "Бульйони", "🍕" to "Піца", "🍰" to "Десерти"),
            listOf("☕" to "Напої", "🌿" to "Healthy", "🔥" to "Новинки", "%" to "Акції")
        )
        rows.forEach { rowData ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowData.forEach { pair ->
                val b = Button(this).apply {
                    text = "${pair.first}\n${pair.second}"
                    textSize = 11.5f
                    setTextColor(white)
                    background = rounded(panel, 17)
                    isAllCaps = false
                    setOnClickListener {
                        selectedCategory = when (pair.second) {
                            "Бургери" -> "Бургери"
                            "Піца" -> "Піца"
                            "Десерти" -> "Десерти"
                            "Напої" -> "Напої"
                            "Healthy" -> "Healthy"
                            else -> "Усе"
                        }
                        showMenu()
                    }
                }
                val lp = LinearLayout.LayoutParams(0, dp(78), 1f)
                lp.setMargins(0, 0, dp(6), dp(6))
                row.addView(b, lp)
            }
            grid.addView(row)
        }
        content.addView(grid)

        val popularHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val popular = TextView(this).apply {
            text = "Популярне"
            textSize = 23f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        popularHeader.addView(popular, LinearLayout.LayoutParams(0, dp(50), 1f))
        val all = Button(this).apply {
            text = "Дивитись всі  ›"
            textSize = 13f
            setTextColor(white)
            background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            isAllCaps = false
            setOnClickListener { showMenu() }
        }
        popularHeader.addView(all, LinearLayout.LayoutParams(dp(132), dp(50)))
        content.addView(popularHeader)

        val productsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val homeProducts = listOf(products[0] to "product_burger.png", products[6] to "product_bowl.png")
        homeProducts.forEach { (p, assetName) ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                clipChildren = false
                clipToPadding = false
                background = rounded(panel, 18)
                setPadding(dp(5), dp(5), dp(5), dp(6))
                setOnClickListener { showProduct(p) }
            }
            val image = ImageView(this).apply {
                setImageBitmap(android.graphics.BitmapFactory.decodeStream(assets.open(assetName)))
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = rounded(panel2, 14)
                clipToOutline = true
            }
            card.addView(image, LinearLayout.LayoutParams(-1, dp(105)))
            val name = TextView(this).apply {
                text = p.name
                textSize = 14f
                setTextColor(white)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(6), dp(5), dp(4), 0)
                maxLines = 1
            }
            card.addView(name)
            val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val price = TextView(this).apply {
                text = "${p.price} ₴"
                textSize = 15f
                setTextColor(yellow)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(6), 0, 0, 0)
            }
            bottom.addView(price, LinearLayout.LayoutParams(0, dp(42), 1f))
            val add = Button(this).apply {
                text = "+"
                textSize = 22f
                setTextColor(Color.BLACK)
                isAllCaps = false
                minWidth = 0
                minHeight = 0
                setPadding(0, 0, 0, 0)
                tag = "cart_plus"
                background = rounded(yellow, 13)
                elevation = dp(7).toFloat()
                contentDescription = "Додати ${p.name} в кошик"
                isClickable = true
                isFocusable = true
                bringToFront()
                installSmoothPress(this)
                setOnClickListener {
                    cart[p.name] = (cart[p.name] ?: 0) + 1
                    bodyToast("${p.name} додано в кошик")
                    showHome()
                }
            }
            bottom.addView(add, LinearLayout.LayoutParams(dp(48), dp(48)))
            card.addView(bottom)
            val lp = LinearLayout.LayoutParams(0, dp(218), 1f)
            lp.setMargins(0, 0, dp(8), dp(4))
            productsRow.addView(card, lp)
        }
        content.addView(productsRow)
    }

    private fun bodyToast(message: String) {
        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun paymentButton(method: String) {
        val selected = paymentMethod == method
        val label = if (selected) "✓ $method" else method
        secondaryButton(label) {
            if (method.startsWith("💳")) {
                showCardPayment()
            } else {
                paymentMethod = method
                if (selectedHub != null && cart.isNotEmpty()) showCheckout()
                else showProfileSection("Способи оплати", "Керуй доступними способами оплати замовлень.")
            }
        }
    }

    private fun inputField(hint: String, value: String = "", inputType: Int = android.text.InputType.TYPE_CLASS_TEXT): EditText {
        return EditText(this).apply {
            this.hint = hint
            setText(value)
            textSize = 15f
            setTextColor(white)
            setHintTextColor(muted)
            setSingleLine(true)
            this.inputType = inputType
            background = rounded(panel2, 14)
            setPadding(dp(14), 0, dp(14), 0)
        }
    }

    private fun showCardPayment() {
        shell("Оплата карткою")
        heading("Банківська картка", 27f)
        body(
            if (cardLast4.isEmpty()) "Введи дані картки. CVV не зберігається на пристрої."
            else "Для нової картки введи повний номер. Збережена: •••• $cardLast4",
            14f
        )

        val number = inputField(
            "Номер картки",
            "",
            android.text.InputType.TYPE_CLASS_NUMBER
        )
        val holder = inputField("Ім'я власника", cardHolder)
        val expiry = inputField("MM/YY", cardExpiry, android.text.InputType.TYPE_CLASS_NUMBER)
        val cvv = inputField("CVV", "", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        content.addView(number, LinearLayout.LayoutParams(-1, dp(56)).apply { setMargins(0, dp(6), 0, dp(6)) })
        content.addView(holder, LinearLayout.LayoutParams(-1, dp(56)).apply { setMargins(0, dp(6), 0, dp(6)) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(expiry, LinearLayout.LayoutParams(0, dp(56), 1f).apply { setMargins(0, dp(6), dp(6), dp(6)) })
        row.addView(cvv, LinearLayout.LayoutParams(0, dp(56), 1f).apply { setMargins(dp(6), dp(6), 0, dp(6)) })
        content.addView(row)

        val save = Button(this).apply {
            text = if (cardLast4.isEmpty()) "Зберегти картку" else "Оновити картку"
            textSize = 17f
            setTextColor(Color.BLACK)
            background = rounded(yellow, 17)
            isAllCaps = false
            setOnClickListener {
                val digits = number.text.toString().filter { it.isDigit() }
                val last4 = if (digits.length >= 4) digits.takeLast(4) else cardLast4
                val cvvDigits = cvv.text.toString().filter { it.isDigit() }
                if (last4.length != 4 || holder.text.toString().trim().isEmpty() || expiry.text.toString().trim().length < 4 || cvvDigits.length < 3) {
                    bodyToast("Перевір дані картки")
                    return@setOnClickListener
                }
                cardLast4 = last4
                cardExpiry = expiry.text.toString().trim()
                cardHolder = holder.text.toString().trim()
                prefs.edit().putString("card_last4", cardLast4).putString("card_expiry", cardExpiry).putString("card_holder", cardHolder).apply()
                paymentMethod = "💳 Банківська картка •••• $cardLast4"
                bodyToast("Картку збережено")
                if (cart.isNotEmpty() && selectedHub != null) showCheckout() else showProfileSection("Способи оплати", "Картка •••• $cardLast4 · $cardHolder")
            }
        }
        content.addView(save, LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(0, dp(14), 0, dp(8)) })
        if (cardLast4.isNotEmpty()) body("Збережена картка: •••• $cardLast4", 14f, yellow)
        secondaryButton("← Назад") { showProfileSection("Способи оплати", "Керуй доступними способами оплати замовлень.") }
    }

    private fun showCheckout() {
        shell("Оформлення")
        heading("Оформлення замовлення", 27f)
        val hub = selectedHub ?: "Не обрано"
        if (deliveryMethod == "drone") {
            body("📍 Адреса доставки", 13f, yellow)
            secondaryButton("Вул. Стрийська, 45, Львів  ›") { showProfileSection("Мої адреси", "Обери або додай адресу доставки.") }
        } else {
            body("📍 Точка самовивозу", 13f, yellow)
            secondaryButton("$hub  ›") { showHubs() }
        }

        sectionLabel("Спосіб доставки")
        if (deliveryMethod == "drone") {
            secondaryButton("✓ 🚁 Дроном  ·  5–15 хв") { deliveryMethod = "drone"; showCart() }
        } else {
            secondaryButton("✓ 🛍️ Самовивіз  ·  30–45 хв") { deliveryMethod = "pickup"; showCart() }
        }

        sectionLabel("Оплата")
        paymentButton("💳 Банківська картка")
        paymentButton("💵 Готівка при отриманні")
        paymentButton("🟢 Google Pay")
        paymentButton(" Apple Pay")
        body("Обрано: $paymentMethod", 14f, yellow)

        val subtotal = cart.entries.sumOf { entry ->
            val product = products.firstOrNull { it.name == entry.key }
            (product?.price ?: 0) * entry.value
        }
        body("Сума страв: $subtotal ₴", 16f, white)
        val deliveryFee = if (deliveryMethod == "drone") 29 else 0
        body(if (deliveryFee > 0) "Доставка BEEGO: $deliveryFee ₴" else "Самовивіз: 0 ₴", 16f, white)
        heading("Разом: ${subtotal + deliveryFee} ₴", 24f)

        val confirm = Button(this).apply {
            text = "Підтвердити замовлення"
            textSize = 17f
            setTextColor(Color.BLACK)
            background = rounded(yellow, 17)
            isAllCaps = false
            setOnClickListener {
                orderConfirmed = true
                trackingStage = 1
                showTrack()
            }
        }
        content.addView(confirm, LinearLayout.LayoutParams(-1, dp(58)))
        secondaryButton("← До кошика") { showCart() }
    }

    private fun showDelivered() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        // HD artwork is clean: the baked-in X and stars are removed.
        val artwork = ImageView(this).apply {
            setImageBitmap(android.graphics.BitmapFactory.decodeStream(assets.open("delivery_completed.png")))
            scaleType = ImageView.ScaleType.FIT_XY
            contentDescription = "Замовлення доставлено"
        }
        root.addView(artwork, FrameLayout.LayoutParams(-1, -1))

        // Separate green success badge with a new animation: fade + slide + overshoot + pulse.
        val check = TextView(this).apply {
            text = "✓"
            textSize = 58f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(76, 210, 105))
                setStroke(dp(3), Color.rgb(205, 255, 215))
            }
            elevation = dp(18).toFloat()
            alpha = 0f
            scaleX = 0.45f
            scaleY = 0.45f
            rotation = -28f
            translationY = dp(18).toFloat()
            contentDescription = "Доставлено"
        }
        val checkLp = FrameLayout.LayoutParams(dp(118), dp(118), Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        root.addView(check, checkLp)
        check.post {
            checkLp.topMargin = (root.height * 0.275f).toInt()
            check.layoutParams = checkLp
            check.animate().alpha(1f).scaleX(1f).scaleY(1f).rotation(0f).translationY(0f)
                .setDuration(650).setInterpolator(android.view.animation.OvershootInterpolator(1.35f))
                .withEndAction {
                    check.animate().scaleX(1.08f).scaleY(1.08f).setDuration(140)
                        .withEndAction { check.animate().scaleX(1f).scaleY(1f).setDuration(160).start() }.start()
                }.start()
        }

        // Raised 3D CTA: gradient face + separate dark shadow layer + elevation.
        val buttonWrap = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(25).toFloat()
                setColor(Color.rgb(35, 35, 30))
            }
            elevation = dp(16).toFloat()
        }
        val reviewButton = TextView(this).apply {
            text = "Залишити відгук   →"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            typeface = Typeface.DEFAULT_BOLD
            isClickable = true
            isFocusable = true
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFFFFD84D.toInt(), yellow, 0xFFE5A900.toInt())).apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(24).toFloat()
                setStroke(dp(2), Color.rgb(255, 235, 135))
            }
            elevation = dp(10).toFloat()
            translationY = -dp(1).toFloat()
            contentDescription = "Залишити відгук"
            setOnClickListener { showReview(5) }
        }
        buttonWrap.addView(reviewButton, FrameLayout.LayoutParams(-1, dp(62)))
        val buttonLp = FrameLayout.LayoutParams(0, dp(68))
        root.addView(buttonWrap, buttonLp)
        buttonWrap.post {
            val w = root.width
            buttonLp.width = (w * 0.80f).toInt()
            buttonLp.leftMargin = (w * 0.10f).toInt()
            buttonLp.topMargin = (root.height * 0.755f).toInt()
            buttonWrap.layoutParams = buttonLp
        }

        // One and only one working close button.
        val close = TextView(this).apply {
            text = "×"
            textSize = 44f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            isClickable = true
            isFocusable = true
            contentDescription = "Закрити"
            setOnClickListener {
                // The delivered screen must actually close. Calling showTrack()
                // here would immediately reopen this screen when trackingStage >= 4.
                orderConfirmed = false
                trackingStage = 0
                showHome()
            }
        }
        val closeLp = FrameLayout.LayoutParams(dp(70), dp(70), Gravity.TOP or Gravity.RIGHT)
        closeLp.topMargin = dp(28)
        closeLp.rightMargin = dp(12)
        root.addView(close, closeLp)

        present(root)
    }

    private fun showReview(initialRating: Int = 5) {
        shell("Відгук")
        heading("Оціни доставку", 27f)
        body("Як пройшла доставка BEEGO?", 16f, muted)
        sectionLabel("Твоя оцінка")

        var selected = initialRating.coerceIn(1, 5)
        val starRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val starButtons = ArrayList<TextView>()
        fun refreshStars() {
            starButtons.forEachIndexed { index, v ->
                v.text = if (index < selected) "★" else "☆"
            }
        }
        for (i in 1..5) {
            val star = TextView(this).apply {
                textSize = 38f
                gravity = Gravity.CENTER
                setTextColor(yellow)
                isClickable = true
                isFocusable = true
                setOnClickListener { selected = i; refreshStars() }
                contentDescription = "Оцінка $i з 5"
            }
            starButtons.add(star)
            starRow.addView(star, LinearLayout.LayoutParams(dp(58), dp(58)))
        }
        refreshStars()
        content.addView(starRow, LinearLayout.LayoutParams(-1, dp(66)))

        sectionLabel("Коментар")
        val input = EditText(this).apply {
            hint = "Розкажи, що тобі сподобалось…"
            setHintTextColor(muted)
            setTextColor(white)
            setSingleLine(false)
            gravity = Gravity.TOP
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(panel2, 16)
        }
        reviewInput = input
        content.addView(input, LinearLayout.LayoutParams(-1, dp(120)))

        // Emoji + photo tools. Emoji inserts directly into the comment field.
        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val emoji = Button(this).apply {
            text = "😊"
            textSize = 21f
            setTextColor(white)
            isAllCaps = false
            background = rounded(panel, 16)
            setOnClickListener {
                val pos = input.selectionStart.coerceAtLeast(0)
                input.text.insert(pos, "😊 ")
                input.requestFocus()
            }
        }
        tools.addView(emoji, LinearLayout.LayoutParams(dp(64), dp(52)).apply { setMargins(0, dp(8), dp(8), 0) })

        val photo = Button(this).apply {
            text = "📷  Фото"
            textSize = 14f
            setTextColor(white)
            isAllCaps = false
            background = rounded(panel, 16)
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(intent, 4101)
            }
        }
        tools.addView(photo, LinearLayout.LayoutParams(dp(125), dp(52)).apply { setMargins(0, dp(8), 0, 0) })
        content.addView(tools)

        reviewPhotoPreview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            visibility = View.GONE
            background = rounded(panel2, 16)
            clipToOutline = true
        }
        content.addView(reviewPhotoPreview, LinearLayout.LayoutParams(-1, dp(150)).apply { setMargins(0, dp(8), 0, 0) })

        val send = Button(this).apply {
            text = "Надіслати відгук"
            textSize = 17f
            setTextColor(Color.BLACK)
            isAllCaps = false
            background = rounded(yellow, 18)
            setOnClickListener {
                val message = input.text.toString().trim()
                if (selected < 1) {
                    bodyToast("Оберіть оцінку від 1 до 5 ⭐")
                } else if (message.isEmpty() && reviewPhotoUri == null) {
                    bodyToast("Додайте коментар або фото 📷")
                } else {
                    bodyToast("Дякуємо за відгук! 🐝⭐ $selected/5")
                }
            }
        }
        content.addView(send, LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(0, dp(14), 0, dp(8)) })
        secondaryButton("← Назад") { showDelivered() }
    }

    private fun showTrack() {
        if (orderConfirmed && trackingStage >= 4) {
            showDelivered()
            return
        }
        // Working BEEGO tracking screen based on the supplied reference.
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(3, 7, 10))
        }

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(3, 7, 10))
        }
        root.addView(page, FrameLayout.LayoutParams(-1, -1))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), 0)
        }

        val titleRow = FrameLayout(this)

        val back = TextView(this).apply {
            text = "‹"
            textSize = 50f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setOnClickListener { showMenu() }
        }
        titleRow.addView(back, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.START))

        val title = TextView(this).apply {
            text = "Ваше замовлення"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        titleRow.addView(title, FrameLayout.LayoutParams(-1, dp(56), Gravity.CENTER))
        top.addView(titleRow)

        val subtitle = TextView(this).apply {
            text = if (orderConfirmed) "У дорозі дроном" else "Підготовка замовлення"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(12))
        }
        top.addView(subtitle)

        val scroll = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            isFillViewport = false
        }

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), 0, dp(18), dp(28))
        }

        // Hero image: no phone frame, no UI elements, no stretched aspect ratio.
        val hero = ImageView(this).apply {
            setImageBitmap(android.graphics.BitmapFactory.decodeStream(
                assets.open("drone_lviv_tracking_hero.png")
            ))
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.BLACK, 18)
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: android.graphics.Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(18).toFloat())
                }
            }
            clipToOutline = true
            contentDescription = "BEEGO drone delivery over Lviv"
            isDrawingCacheEnabled = false
        }
        body.addView(hero, LinearLayout.LayoutParams(dp(317), dp(178)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            setMargins(0, 0, 0, dp(14))
        })

        val names = listOf(
            "Замовлення прийнято",
            "Страви готуються",
            "Передано дрону",
            "Дрон у повітрі",
            "Доставлено"
        )
        val times = listOf("14:07", "14:10", "14:18", "", "")

        names.forEachIndexed { index, name ->
            val completed = orderConfirmed && index < trackingStage
            val current = orderConfirmed && index == trackingStage
            val initial = !orderConfirmed && index == 0

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.TOP
            }

            val track = object : View(this) {
                private val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
                override fun onDraw(c: android.graphics.Canvas) {
                    val x = width / 2f

                    if (index < names.lastIndex) {
                        p.style = android.graphics.Paint.Style.STROKE
                        p.strokeWidth = dp(2).toFloat()
                        p.color = if (completed) yellow else Color.rgb(105, 111, 116)
                        c.drawLine(x, dp(30).toFloat(), x, height.toFloat(), p)
                    }

                    p.style = android.graphics.Paint.Style.FILL
                    p.color = when {
                        completed || current || initial -> yellow
                        else -> Color.rgb(145, 151, 156)
                    }
                    c.drawCircle(x, dp(18).toFloat(), dp(14).toFloat(), p)

                    if (completed || initial) {
                        p.color = Color.rgb(15, 18, 20)
                        p.textSize = dp(18).toFloat()
                        p.textAlign = android.graphics.Paint.Align.CENTER
                        c.drawText("✓", x, dp(25).toFloat(), p)
                    } else if (current) {
                        p.color = Color.rgb(15, 18, 20)
                        p.textSize = dp(12).toFloat()
                        p.textAlign = android.graphics.Paint.Align.CENTER
                        c.drawText("●", x, dp(23).toFloat(), p)
                    }
                }
            }
            row.addView(track, LinearLayout.LayoutParams(dp(40), dp(70)))

            val label = TextView(this).apply {
                text = when {
                    current && index == 1 -> "Страви готуються\nВаше замовлення вже готується"
                    current && index == 2 -> "Передано дрону\nДрон забирає замовлення"
                    current && index == 3 -> "Дрон у повітрі\nДо прибуття: 3 хв"
                    current && index == 4 -> "Доставлено\nЗамовлення прибуло"
                    else -> {
                        val t = times.getOrNull(index).orEmpty()
                        if (t.isNotEmpty()) "$name\n$t" else name
                    }
                }
                textSize = if (current) 18f else 16f
                setTextColor(
                    when {
                        current || completed || initial -> Color.WHITE
                        else -> Color.rgb(155, 160, 165)
                    }
                )
                typeface = if (current) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                setPadding(0, dp(2), 0, 0)
            }
            row.addView(label, LinearLayout.LayoutParams(0, dp(70), 1f))
            body.addView(row)
        }

        val eta = TextView(this).apply {
            text = when {
                !orderConfirmed -> "Підтвердь замовлення, щоб запустити доставку."
                trackingStage == 1 -> "Ресторан готує замовлення"
                trackingStage == 2 -> "Замовлення передано дрону"
                trackingStage == 3 -> "До прибуття: 3 хв"
                trackingStage >= 4 -> "Замовлення прибуло в HUB"
                else -> "Підготовка доставки"
            }
            textSize = 15f
            setTextColor(if (orderConfirmed) Color.WHITE else yellow)
            setPadding(dp(44), dp(2), 0, dp(14))
        }
        body.addView(eta)

        // Real interactive OpenStreetMap-based tracking map.
        // The map is native, zoomable and pannable; the BEEGO route and drone
        // are drawn on top so the screen remains functional without a static image.
        val mapHost = FrameLayout(this)
        val beegoTileSource = object : OnlineTileSourceBase(
            "BEEGO OSM",
            1,
            19,
            256,
            ".png",
            arrayOf("https://tile.openstreetmap.org/")
        ) {
            override fun getTileURLString(pMapTileIndex: Long): String {
                return getBaseUrl() +
                    MapTileIndex.getZoom(pMapTileIndex) + "/" +
                    MapTileIndex.getX(pMapTileIndex) + "/" +
                    MapTileIndex.getY(pMapTileIndex) +
                    mImageFilenameEnding
            }
        }

        fun createTrackingMap(): MapView {
            val m = MapView(this).apply {
                setTileSource(beegoTileSource)
                setUseDataConnection(true)
                setMultiTouchControls(true)
                isClickable = true
                minZoomLevel = 10.0
                maxZoomLevel = 19.0
                controller.setZoom(13.4)
                controller.setCenter(GeoPoint(49.8397, 24.0297))
                setBackgroundColor(Color.rgb(20, 24, 25))
                overlayManager.tilesOverlay.setLoadingBackgroundColor(Color.rgb(20, 24, 25))
                overlayManager.tilesOverlay.setLoadingLineColor(Color.rgb(20, 24, 25))
                contentDescription = "Інтерактивна карта маршруту BEEGO"
            }

            val route = Polyline().apply {
                outlinePaint.color = yellow
                outlinePaint.strokeWidth = dp(5).toFloat()
                outlinePaint.isAntiAlias = true
                setPoints(
                    listOf(
                        GeoPoint(49.8397, 24.0297),
                        GeoPoint(49.8422, 24.0228),
                        GeoPoint(49.8455, 24.0147),
                        GeoPoint(49.8338, 24.0024)
                    )
                )
            }
            m.overlays.add(route)

            val destination = Marker(m).apply {
                position = GeoPoint(49.8338, 24.0024)
                setTitle("Пункт отримання")
                setSnippet("BEEGO HUB")
                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                icon = makeMapPin(yellow, "⌂")
            }
            m.overlays.add(destination)

            val drone = Marker(m).apply {
                position = GeoPoint(49.8397, 24.0297)
                setTitle("Дрон BEEGO")
                setSnippet("BG-017 • у польоті")
                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                icon = makeMapPin(yellow, "✦")
            }
            m.overlays.add(drone)

            m.onResume()
            m.post {
                m.controller.setCenter(GeoPoint(49.8397, 24.0297))
                m.controller.setZoom(13.4)
                m.invalidate()
            }
            return m
        }

        val map = createTrackingMap()
        trackingMap = map
        // showTrack() can be called after Activity.onResume(), therefore make
        // sure osmdroid itself is also resumed for this newly-created map.
        map.onResume()

        val route = Polyline().apply {
            outlinePaint.color = yellow
            outlinePaint.strokeWidth = dp(5).toFloat()
            outlinePaint.isAntiAlias = true
            setPoints(
                listOf(
                    GeoPoint(49.8397, 24.0297),
                    GeoPoint(49.8422, 24.0228),
                    GeoPoint(49.8455, 24.0147),
                    GeoPoint(49.8338, 24.0024)
                )
            )
        }
        map.overlays.add(route)

        val destination = Marker(map).apply {
            position = GeoPoint(49.8338, 24.0024)
            setTitle("Пункт отримання")
            setSnippet("BEEGO HUB")
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            icon = makeMapPin(yellow, "⌂")
        }
        map.overlays.add(destination)

        val drone = Marker(map).apply {
            position = GeoPoint(49.8397, 24.0297)
            setTitle("Дрон BEEGO")
            setSnippet("BG-017 • у польоті")
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
            icon = makeMapPin(yellow, "✦")
        }
        map.overlays.add(drone)
        map.post {
            map.controller.setCenter(GeoPoint(49.8397, 24.0297))
            map.controller.setZoom(13.4)
            map.invalidate()
        }

        mapHost.addView(map, FrameLayout.LayoutParams(-1, -1))
        val mapButton = TextView(this).apply {
            text = "⛶"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(Color.argb(220, 25, 28, 28), 14)
            elevation = dp(5).toFloat()
            contentDescription = "Збільшити карту"
        }
        val buttonLp = FrameLayout.LayoutParams(dp(52), dp(52), Gravity.TOP or Gravity.END).apply {
            setMargins(0, dp(12), dp(12), 0)
        }
        mapHost.addView(mapButton, buttonLp)

        mapHost.background = rounded(panel2, 18)
        mapHost.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: android.graphics.Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(18).toFloat())
            }
        }
        mapHost.clipToOutline = true
        body.addView(mapHost, LinearLayout.LayoutParams(-1, dp(285)).apply {
            setMargins(0, 0, 0, dp(14))
        })

        var mapExpanded = false
        var fullscreenHost: FrameLayout? = null
        var fullscreenMap: MapView? = null

        mapButton.setOnClickListener {
            if (!mapExpanded) {
                mapExpanded = true

                // IMPORTANT: never move the working MapView between parents.
                // osmdroid can lose its tile renderer after re-parenting on Android.
                // Keep the small map intact and create a fresh fullscreen MapView.
                val host = FrameLayout(this).apply {
                    setBackgroundColor(Color.rgb(20, 24, 25))
                    clipToPadding = false
                }
                val bigMap = createTrackingMap()
                fullscreenMap = bigMap
                fullscreenHost = host

                host.addView(bigMap, FrameLayout.LayoutParams(-1, -1))

                val close = TextView(this).apply {
                    text = "✕"
                    textSize = 34f
                    gravity = Gravity.CENTER
                    setTextColor(Color.WHITE)
                    background = rounded(Color.argb(225, 25, 28, 28), 16)
                    elevation = dp(8).toFloat()
                    contentDescription = "Згорнути карту"
                    setOnClickListener { mapButton.performClick() }
                }
                host.addView(
                    close,
                    FrameLayout.LayoutParams(dp(64), dp(64), Gravity.TOP or Gravity.END).apply {
                        setMargins(0, dp(18), dp(18), 0)
                    }
                )

                root.addView(host, FrameLayout.LayoutParams(-1, -1))
                map.post {
                    map.invalidate()
                }
                bigMap.post {
                    bigMap.requestLayout()
                    bigMap.controller.setCenter(GeoPoint(49.8397, 24.0297))
                    bigMap.controller.setZoom(13.4)
                    bigMap.invalidate()
                    bigMap.postDelayed({ bigMap.invalidate() }, 500L)
                    bigMap.postDelayed({ bigMap.invalidate() }, 1500L)
                }
            } else {
                mapExpanded = false

                fullscreenHost?.let { host ->
                    (host.parent as? ViewGroup)?.removeView(host)
                }
                fullscreenMap?.onPause()
                fullscreenMap = null
                fullscreenHost = null

                map.post {
                    map.requestLayout()
                    map.setTileSource(beegoTileSource)
                    map.setUseDataConnection(true)
                    map.controller.setCenter(GeoPoint(49.8397, 24.0297))
                    map.controller.setZoom(13.4)
                    map.invalidate()
                    map.postDelayed({ map.invalidate() }, 300L)
                }
            }
        }

        if (orderConfirmed && trackingStage < 4) {
            val next = Button(this).apply {
                text = when (trackingStage) {
                    1 -> "Страви готові"
                    2 -> "🚁 Дрон вилетів"
                    3 -> "Підтвердити доставку"
                    else -> "Оновити статус"
                }
                textSize = 16f
                setTextColor(Color.BLACK)
                background = rounded(yellow, 18)
                isAllCaps = false
                setOnClickListener {
                    trackingStage = (trackingStage + 1).coerceAtMost(4)
                    showTrack()
                }
            }
            body.addView(next, LinearLayout.LayoutParams(-1, dp(56)).apply {
                setMargins(0, 0, 0, dp(10))
            })
        }

        val backButton = Button(this).apply {
            text = "← Повернутися до меню"
            textSize = 16f
            setTextColor(Color.WHITE)
            background = rounded(panel2, 18)
            isAllCaps = false
            setOnClickListener { showMenu() }
        }
        body.addView(backButton, LinearLayout.LayoutParams(-1, dp(54)))

        scroll.addView(body)
        page.addView(top)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        present(root)
    }

    private fun makeMapPin(color: Int, symbol: String): android.graphics.drawable.Drawable {
        val size = dp(46)
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.color = Color.argb(245, 8, 10, 10)
        paint.style = android.graphics.Paint.Style.FILL
        val textPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        textPaint.color = color
        textPaint.textSize = dp(22).toFloat()
        textPaint.textAlign = android.graphics.Paint.Align.CENTER
        return object : android.graphics.drawable.Drawable() {
            init { setBounds(0, 0, size, size) }
            override fun draw(canvas: android.graphics.Canvas) {
                val cx = bounds.exactCenterX()
                val cy = bounds.exactCenterY()
                canvas.drawCircle(cx, cy, size * 0.43f, paint)
                canvas.drawCircle(cx, cy, size * 0.43f, android.graphics.Paint().apply {
                    isAntiAlias = true
                    style = android.graphics.Paint.Style.STROKE
                    strokeWidth = dp(2).toFloat()
                    this.color = color
                })
                canvas.drawText(symbol, cx, cy - (textPaint.ascent() + textPaint.descent()) / 2f, textPaint)
            }
            override fun setAlpha(alpha: Int) { paint.alpha = alpha; textPaint.alpha = alpha }
            override fun setColorFilter(filter: android.graphics.ColorFilter?) { paint.colorFilter = filter; textPaint.colorFilter = filter }
            override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
        }
    }

    /**
     * Premium press feedback without alpha changes. Alpha flashes are especially
     * noticeable on Android during full-screen view replacement, so buttons use
     * only physical motion/scale and a temporary elevation change.
     */
    /**
     * Soft quantity-button feedback. The old press effect was too abrupt on
     * fast menu refreshes because the click immediately replaced the screen.
     * Keep the visual motion tiny and let the action fire shortly after release.
     */
    private fun installSoftPlusPress(view: View) {
        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    v.animate().cancel()
                    v.animate()
                        .scaleX(0.985f).scaleY(0.985f)
                        .translationY(dp(1).toFloat())
                        .setDuration(110L)
                        .setInterpolator(android.view.animation.DecelerateInterpolator())
                        .start()
                    true
                }
                android.view.MotionEvent.ACTION_UP -> {
                    v.animate().cancel()
                    v.animate()
                        .scaleX(1f).scaleY(1f)
                        .translationY(0f)
                        .setDuration(210L)
                        .setInterpolator(android.view.animation.PathInterpolator(0.16f, 0.9f, 0.25f, 1f))
                        .start()
                    // Give the release animation a moment before replacing the menu.
                    v.postDelayed({ if (v.isAttachedToWindow) v.performClick() }, 65L)
                    true
                }
                android.view.MotionEvent.ACTION_CANCEL -> {
                    v.animate().cancel()
                    v.animate()
                        .scaleX(1f).scaleY(1f)
                        .translationY(0f)
                        .setDuration(180L)
                        .setInterpolator(android.view.animation.DecelerateInterpolator())
                        .start()
                    true
                }
                else -> true
            }
        }
    }

    private fun installSmoothPress(view: View) {
        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    v.animate().cancel()
                    v.animate()
                        .scaleX(0.965f).scaleY(0.965f)
                        .translationY(dp(2).toFloat())
                        .setDuration(80L)
                        .setInterpolator(android.view.animation.DecelerateInterpolator())
                        .start()
                    true
                }
                android.view.MotionEvent.ACTION_UP -> {
                    v.performClick()
                    v.animate().cancel()
                    v.animate()
                        .scaleX(1f).scaleY(1f)
                        .translationY(0f)
                        .setDuration(150L)
                        .setInterpolator(android.view.animation.OvershootInterpolator(1.15f))
                        .start()
                    true
                }
                android.view.MotionEvent.ACTION_CANCEL -> {
                    v.animate().cancel()
                    v.animate()
                        .scaleX(1f).scaleY(1f)
                        .translationY(0f)
                        .setDuration(130L)
                        .setInterpolator(android.view.animation.DecelerateInterpolator(1.5f))
                        .start()
                    true
                }
                else -> true
            }
        }
    }

    private fun applyGlobal3DButtons(view: View) {
        if (view is Button) {
            // Keep navigation compact. All other buttons get a lightweight
            // 3D surface. Do not force software rendering: that causes
            // expensive full-view redraws and visible stutter on Android.
            if (!view.text.toString().contains("\n") && view.tag != "cart_plus") {
                val primary = view.currentTextColor == Color.BLACK
                val top = if (primary) Color.rgb(255, 216, 66) else Color.rgb(57, 61, 61)
                val bottom = if (primary) Color.rgb(226, 158, 0) else Color.rgb(24, 27, 27)
                val stroke = if (primary) Color.rgb(255, 232, 132) else Color.rgb(76, 80, 80)
                view.background = GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM,
                    intArrayOf(top, bottom)
                ).apply {
                    cornerRadius = dp(17).toFloat()
                    setStroke(dp(1), stroke)
                }
                view.elevation = dp(5).toFloat()
                view.stateListAnimator = null
                view.setOnTouchListener { v, event ->
                    when (event.actionMasked) {
                        android.view.MotionEvent.ACTION_DOWN -> {
                            v.animate().cancel()
                            v.animate()
                                .scaleX(0.975f).scaleY(0.975f)
                                .translationY(dp(1).toFloat())
                                .setDuration(70L)
                                .setInterpolator(android.view.animation.DecelerateInterpolator())
                                .start()
                            true
                        }
                        android.view.MotionEvent.ACTION_UP -> {
                            // Trigger the action immediately; visual recovery runs
                            // independently so there is no artificial tap delay.
                            v.performClick()
                            v.animate().cancel()
                            v.animate()
                                .scaleX(1f).scaleY(1f)
                                .translationY(0f)
                                .setDuration(145L)
                                .setInterpolator(android.view.animation.PathInterpolator(0.2f, 0.85f, 0.25f, 1f))
                                .start()
                            true
                        }
                        android.view.MotionEvent.ACTION_CANCEL -> {
                            v.animate().cancel()
                            v.animate()
                                .scaleX(1f).scaleY(1f)
                                .translationY(0f)
                                .setDuration(110L)
                                .setInterpolator(android.view.animation.DecelerateInterpolator())
                                .start()
                            true
                        }
                        else -> true
                    }
                }
            }
        }
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                applyGlobal3DButtons(view.getChildAt(i))
            }
        }
    }

    private fun present(root: View) {
        // Keep one Activity/window and animate only the screen container.
        // Repeated setContentView() calls were causing layout/focus churn and
        // the visible jump when a new page was selected.
        root.translationX = dp(14).toFloat()
        root.translationY = 0f
        root.scaleX = 1f
        root.scaleY = 1f
        root.alpha = 1f
        applyGlobal3DButtons(root)

        val old = currentScreen
        screenHost.removeAllViews()
        screenHost.addView(root, FrameLayout.LayoutParams(-1, -1))
        currentScreen = root
        hideSystemBars()

        root.post {
            root.animate().cancel()
            root.animate()
                .translationX(0f)
                .setDuration(180L)
                .setInterpolator(android.view.animation.PathInterpolator(0.16f, 0.82f, 0.2f, 1f))
                .start()
            old?.animate()?.cancel()
        }
    }

    private fun hubImage(asset: String, widthDp: Int, heightDp: Int): ImageView {
        return ImageView(this).apply {
            setImageBitmap(loadMenuCardBitmap(asset))
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(panel2, 16)
            clipToOutline = true
            contentDescription = "BEEGO HUB"
            layoutParams = LinearLayout.LayoutParams(dp(widthDp), dp(heightDp))
        }
    }

    private fun hubCard(hub: String, address: String, imageAsset: String, action: () -> Unit) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = rounded(panel, 18)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
            elevation = dp(2).toFloat()
        }

        card.addView(hubImage(imageAsset, 118, 104),
            LinearLayout.LayoutParams(dp(118), dp(104)))

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(6), 0)
        }
        val name = TextView(this).apply {
            text = "📍 $hub"
            textSize = 15f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 2
        }
        info.addView(name, LinearLayout.LayoutParams(-1, dp(42)))

        val addr = TextView(this).apply {
            text = "⌖ $address"
            textSize = 12f
            setTextColor(muted)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        info.addView(addr, LinearLayout.LayoutParams(-1, dp(24)))

        val meta = TextView(this).apply {
            text = "📦 Отримання  •  🚁 Drone Delivery  •  24/7"
            textSize = 10f
            setTextColor(yellow)
            maxLines = 2
        }
        info.addView(meta, LinearLayout.LayoutParams(-1, dp(34)))
        card.addView(info, LinearLayout.LayoutParams(0, dp(104), 1f))

        val arrow = TextView(this).apply {
            text = "→"
            textSize = 28f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            background = rounded(yellow, 16)
        }
        card.addView(arrow, LinearLayout.LayoutParams(dp(52), dp(52)))

        val lp = LinearLayout.LayoutParams(-1, dp(124))
        lp.setMargins(0, dp(6), 0, dp(6))
        content.addView(card, lp)
    }

    private fun showHubs() {
        shell("BEEGO HUB")

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(panel, 20)
            setPadding(dp(14), dp(12), dp(8), dp(12))
            clipToOutline = true
        }
        val heroText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(2), 0, dp(8), 0)
        }
        val h = TextView(this).apply {
            text = "BEEGO HUB"
            textSize = 26f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        heroText.addView(h)
        val sub = TextView(this).apply {
            text = "Швидке та зручне отримання замовлень у Львові"
            textSize = 13f
            setTextColor(muted)
            setPadding(0, dp(4), 0, dp(6))
        }
        heroText.addView(sub)
        val perks = TextView(this).apply {
            text = "⚡ Швидко   🛡 Безпечно   ♻ Екологічно"
            textSize = 10f
            setTextColor(yellow)
        }
        heroText.addView(perks)
        hero.addView(heroText, LinearLayout.LayoutParams(0, dp(142), 1f))
        hero.addView(hubImage("beego_hub.png", 148, 142), LinearLayout.LayoutParams(dp(148), dp(142)))

        val heroLp = LinearLayout.LayoutParams(-1, dp(166))
        heroLp.setMargins(0, dp(4), 0, dp(12))
        content.addView(hero, heroLp)

        heading("BEEGO HUB", 29f)
        body("Обери точку отримання замовлення.", 15f)

        hubCard("Площа Ринок — HUB 01", "пл. Ринок, Львів", "beego_hub_rinok.png") { showHubDetails("Площа Ринок — HUB 01") }
        hubCard("Сихів — HUB 02", "просп. Червоної Калини, Львів", "beego_hub_sykhiv.png") { showHubDetails("Сихів — HUB 02") }
        hubCard("Наукова — HUB 03", "вул. Наукова, Львів", "beego_hub_naukova.png") { showHubDetails("Наукова — HUB 03") }
        hubCard("Левандівка — HUB 04", "вул. Широка, Львів", "beego_hub_levandivka.png") { showHubDetails("Левандівка — HUB 04") }

        val safety = TextView(this).apply {
            text = "🛡  Безпечні точки прийому та видачі замовлень.\n     BEEGO — завжди поруч."
            textSize = 13f
            setTextColor(white)
            background = rounded(panel2, 18)
            setPadding(dp(16), dp(12), dp(12), dp(12))
        }
        val safetyLp = LinearLayout.LayoutParams(-1, dp(72))
        safetyLp.setMargins(0, dp(8), 0, dp(12))
        content.addView(safety, safetyLp)
    }

    private fun hubDetailImage(hub: String): String {
        return when {
            hub.contains("Площа Ринок") -> "beego_hub_rinok.png"
            hub.contains("Сихів") -> "beego_hub_sykhiv.png"
            hub.contains("Наукова") -> "beego_hub_naukova.png"
            hub.contains("Левандівка") -> "beego_hub_levandivka.png"
            else -> "beego_hub.png"
        }
    }

    private fun hubFeature(icon: String, title: String, subtitle: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(8), dp(6), dp(7))
            background = rounded(panel2, 15)
            elevation = dp(2).toFloat()

            addView(TextView(this@MainActivity).apply {
                text = icon
                textSize = 24f
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(-1, dp(34)))

            addView(TextView(this@MainActivity).apply {
                text = title
                textSize = 11f
                setTextColor(white)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                maxLines = 1
            }, LinearLayout.LayoutParams(-1, dp(24)))

            addView(TextView(this@MainActivity).apply {
                text = subtitle
                textSize = 8f
                setTextColor(muted)
                gravity = Gravity.CENTER
                maxLines = 2
            }, LinearLayout.LayoutParams(-1, dp(28)))
        }
    }

    private fun showHubDetails(hub: String) {
        shell("BEEGO HUB")

        // Each HUB detail page uses its own dedicated photo.
        val hero = hubImage(hubDetailImage(hub), 0, 190)
        hero.scaleType = ImageView.ScaleType.CENTER_CROP
        val heroLp = LinearLayout.LayoutParams(-1, dp(190))
        heroLp.setMargins(0, dp(4), 0, dp(12))
        content.addView(hero, heroLp)

        heading(hub, 25f)
        body("📍 Львів  •  🟢 HUB доступний для отримання", 14f, white)
        body("📦 Автоматична видача замовлення\n🚁 Drone Delivery до HUB\n⏱ Орієнтовно 8–12 хв", 14f)

        val select = Button(this).apply {
            text = "Обрати цей HUB  →"
            textSize = 17f
            setTextColor(Color.BLACK)
            isAllCaps = false
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.rgb(255, 216, 66), Color.rgb(226, 158, 0))
            ).apply {
                cornerRadius = dp(17).toFloat()
                setStroke(dp(1), Color.rgb(255, 232, 132))
            }
            elevation = dp(6).toFloat()
            setOnClickListener {
                selectedHub = hub
                trackingStage = 0
                showCart()
            }
        }
        val selectLp = LinearLayout.LayoutParams(-1, dp(60))
        selectLp.setMargins(0, dp(2), 0, dp(8))
        content.addView(select, selectLp)

        val back = Button(this).apply {
            text = "←  До списку HUB"
            textSize = 16f
            setTextColor(white)
            isAllCaps = false
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.rgb(57, 61, 61), Color.rgb(24, 27, 27))
            ).apply {
                cornerRadius = dp(17).toFloat()
                setStroke(dp(1), Color.rgb(76, 80, 80))
            }
            elevation = dp(5).toFloat()
            setOnClickListener { showHubs() }
        }
        content.addView(back, LinearLayout.LayoutParams(-1, dp(58)))

        val features = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val featureData = listOf(
            Triple("⚡", "Швидко", "Ваше замовлення\nвже тут"),
            Triple("🌿", "Екологічно", "Чисте місто\nдля всіх"),
            Triple("🛡", "Безпечно", "Сучасні технології\nзахищають"),
            Triple("🚁", "Дрон доставка", "Майбутнє\nвже сьогодні")
        )
        featureData.forEachIndexed { index, item ->
            val f = hubFeature(item.first, item.second, item.third)
            val lp = LinearLayout.LayoutParams(0, dp(112), 1f)
            lp.setMargins(if (index == 0) 0 else dp(4), dp(14), if (index == featureData.lastIndex) 0 else dp(4), dp(8))
            features.addView(f, lp)
        }
        content.addView(features, LinearLayout.LayoutParams(-1, dp(134)))
    }

    private fun profileRow(icon: String, title: String, subtitle: String? = null, action: () -> Unit = {}) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(5), dp(10), dp(5))
            background = rounded(if (title == "Вихід") Color.rgb(70, 25, 25) else panel2, 16)
            setOnClickListener { action() }
            isClickable = true
        }

        val iconView = TextView(this).apply {
            text = icon
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(if (title == "Вихід") Color.rgb(235, 70, 70) else white)
        }
        row.addView(iconView, LinearLayout.LayoutParams(dp(38), dp(42)))

        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(5), 0, dp(3), 0)
        }
        val titleView = TextView(this).apply {
            text = title
            textSize = 14f
            setTextColor(if (title == "Вихід") Color.rgb(235, 70, 70) else white)
        }
        texts.addView(titleView)
        if (subtitle != null) {
            val sub = TextView(this).apply {
                text = subtitle
                textSize = 10f
                setTextColor(muted)
                setPadding(0, dp(2), 0, 0)
            }
            texts.addView(sub)
        }
        row.addView(texts, LinearLayout.LayoutParams(0, dp(42), 1f))

        val arrow = TextView(this).apply {
            text = "›"
            textSize = 20f
            setTextColor(if (title == "Вихід") Color.rgb(235, 70, 70) else white)
            gravity = Gravity.CENTER
        }
        row.addView(arrow, LinearLayout.LayoutParams(dp(22), dp(42)))

        val lp = LinearLayout.LayoutParams(-1, dp(if (subtitle == null) 48 else 54))
        lp.setMargins(0, dp(2), 0, dp(2))
        content.addView(row, lp)
    }

    private fun profileShell() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(8))
        }
        val title = TextView(this).apply {
            text = "Профіль"
            textSize = 20f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(42), 1f))

        val settings = Button(this).apply {
            text = "⚙"
            textSize = 20f
            setTextColor(white)
            background = rounded(panel2, 16)
            isAllCaps = false
            setOnClickListener { showProfileSection("Налаштування", "Керуйте налаштуваннями BEEGO.") }
        }
        header.addView(settings, LinearLayout.LayoutParams(dp(44), dp(44)))
        root.addView(header)

        val scroll = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(4), dp(18), dp(24))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(panel)
            setPadding(0, dp(4), 0, dp(4))
        }
        navButton(nav, "⌂", "Головна") { showHome() }
        navButton(nav, "🍔", "Меню") { showMenu() }
        navButton(nav, "🚁", "Дрон") { showTrack() }
        navButton(nav, "📍", "HUB") { showHubs() }
        navButton(nav, "👤", "Профіль") { showProfile() }
        root.addView(nav, LinearLayout.LayoutParams(-1, dp(70)))

        present(root)
    }

    private fun showProfile() {
        profileShell()

        val profileHead = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(8))
        }

        val avatarContainer = FrameLayout(this)
        val avatarImage = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(panel2)
                setStroke(dp(2), Color.rgb(190, 195, 198))
            }
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: android.graphics.Outline) {
                    outline.setOval(0, 0, view.width, view.height)
                }
            }
            contentDescription = "Аватар"
        }
        if (profileAvatarUri != null) avatarImage.setImageURI(profileAvatarUri) else avatarImage.setImageResource(com.beego.app.R.drawable.beego_launcher)
        avatarContainer.addView(avatarImage, FrameLayout.LayoutParams(dp(58), dp(58)))
        val avatarButton = Button(this).apply {
            text = "📷"
            textSize = 11f
            setTextColor(white)
            background = rounded(panel2, 14)
            isAllCaps = false
            setPadding(0,0,0,0)
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(intent, 4201)
            }
        }
        val avlp = FrameLayout.LayoutParams(dp(28), dp(28), Gravity.BOTTOM or Gravity.END)
        avatarContainer.addView(avatarButton, avlp)
        profileHead.addView(avatarContainer, LinearLayout.LayoutParams(dp(64), dp(64)))

        val identity = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        val name = TextView(this).apply {
            text = if (profileName.isBlank()) "Гість BEEGO" else profileName
            textSize = 18f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        identity.addView(name)
        val phone = TextView(this).apply {
            text = if (profilePhone.isBlank()) "Акаунт не зареєстрований" else profilePhone
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(4), 0, 0)
        }
        identity.addView(phone)
        profileHead.addView(identity, LinearLayout.LayoutParams(0, dp(64), 1f))
        content.addView(profileHead, LinearLayout.LayoutParams(-1, dp(78)))

        val accountButton = Button(this).apply {
            text = if (profileName.isBlank()) "👤 Зареєструвати акаунт" else "✏️ Редагувати акаунт"
            textSize = 15f
            setTextColor(Color.BLACK)
            background = rounded(yellow, 17)
            isAllCaps = false
            setOnClickListener { showAccountEditor() }
        }
        content.addView(accountButton, LinearLayout.LayoutParams(-1, dp(56)).apply { setMargins(0, 0, 0, dp(8)) })

        profileRow("▣", "Мої замовлення", action = { showProfileSection("Історія замовлень", "Тут будуть усі твої замовлення BEEGO.") })
        profileRow("⌖", "Мої адреси", action = { showProfileSection("Мої адреси", "Додай HUB-и, які використовуєш найчастіше.") })
        profileRow("▤", "Способи оплати", action = { showProfileSection("Способи оплати", "Керуй доступними способами оплати замовлень.") })
        profileRow("⭐", "BEEGO Plus", "Преміум-доставка", { showProfileSection("BEEGO Plus", "Переваги підписки BEEGO Plus та спеціальні умови.") })
        profileRow("👥", "Запросити друга", "Отримай 100 ₴", {})
        profileRow("◉", "Підтримка", action = { showProfileSection("Підтримка", "Ми допоможемо з замовленням та доставкою.") })
        profileRow("⚙", "Налаштування", action = { showProfileSection("Налаштування", "Керуйте налаштуваннями BEEGO.") })
        profileRow("🔒", "Privacy Policy", action = { showProfileSection("Privacy Policy", "Політика конфіденційності BEEGO." ) })
        profileRow("↪", "Вихід", action = { finishAffinity() })
    }

    private fun showAccountEditor() {
        shell("Акаунт BEEGO")
        heading(if (profileName.isBlank()) "Реєстрація акаунта" else "Мій акаунт", 27f)
        body("Твої дані будуть показуватися у профілі BEEGO.", 14f)
        val name = inputField("Ім'я", profileName)
        val phone = inputField("Номер телефону", profilePhone, android.text.InputType.TYPE_CLASS_PHONE)
        content.addView(name, LinearLayout.LayoutParams(-1, dp(56)).apply { setMargins(0, dp(8), 0, dp(8)) })
        content.addView(phone, LinearLayout.LayoutParams(-1, dp(56)).apply { setMargins(0, dp(8), 0, dp(8)) })
        secondaryButton("📷 Обрати фото аватара") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "image/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            startActivityForResult(intent, 4201)
        }
        val save = Button(this).apply {
            text = "Зберегти акаунт"
            textSize = 17f
            setTextColor(Color.BLACK)
            background = rounded(yellow, 17)
            isAllCaps = false
            setOnClickListener {
                val n = name.text.toString().trim()
                val ph = phone.text.toString().trim()
                if (n.length < 2 || ph.length < 7) { bodyToast("Введи ім'я та номер телефону"); return@setOnClickListener }
                profileName = n
                profilePhone = ph
                prefs.edit().putString("name", n).putString("phone", ph).apply()
                bodyToast("Акаунт збережено")
                showProfile()
            }
        }
        content.addView(save, LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(0, dp(14), 0, dp(8)) })
        secondaryButton("← Назад до профілю") { showProfile() }
    }

    private fun showProfileSection(title: String, description: String) {
        shell("Профіль")
        heading(title, 27f)
        body(description, 16f, white)

        when (title) {
            "Історія замовлень" -> {
                sectionLabel("Замовлення")
                secondaryButton("📦 Замовлення #BEEGO-001") {}
                body("Поки що це демонстраційна історія замовлень.", 14f)
            }
            "Мої адреси" -> {
                sectionLabel("Точки отримання")
                secondaryButton("📍 Площа Ринок — HUB 01") { showHubDetails("Площа Ринок — HUB 01") }
                secondaryButton("📍 Сихів — HUB 02") { showHubDetails("Сихів — HUB 02") }
                secondaryButton("📍 Наукова — HUB 03") { showHubDetails("Наукова — HUB 03") }
                secondaryButton("📍 Левандівка — HUB 04") { showHubDetails("Левандівка — HUB 04") }
            }
            "Способи оплати" -> {
                sectionLabel("Оплата")
                if (cardLast4.isNotEmpty()) body("Збережена картка: •••• $cardLast4", 14f, yellow)
                paymentButton("💳 Банківська картка")
                paymentButton("💵 Готівка при отриманні")
                paymentButton("🟢 Google Pay")
                paymentButton(" Apple Pay")
            }
            "BEEGO Plus" -> {
                sectionLabel("Переваги")
                body("⭐ Пріоритетні можливості BEEGO.", 16f, white)
                body("🚁 Зручне відстеження доставки.", 15f)
                body("🎁 Спеціальні пропозиції для учасників.", 15f)
            }
        }
        secondaryButton("← Назад до профілю") { showProfile() }
    }
}
