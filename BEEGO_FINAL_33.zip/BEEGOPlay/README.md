# BEEGO — Android / Google Play starter

Це нативний Android-проєкт, який пакує локальний BEEGO HTML/JS-прототип у WebView.

## Важливо
Це **Play-ready starter**, а не вже опублікований комерційний сервіс. Для реального запуску потрібні backend, реальна оплата, авторизація, GPS/карти, push, ресторанний кабінет, дронова диспетчеризація, privacy policy, Data Safety та підпис релізу.

## Вимоги
- Android Studio Ladybug/новіше з Android SDK 36
- JDK 17
- Gradle 8.13+ / Android Gradle Plugin 8.13+

## Збірка
В Android Studio відкрий папку `BEEGOPlay`, дочекайся Gradle Sync, потім:
Build → Generate Signed App Bundle / APK → Android App Bundle.

Для Google Play використовуй **AAB**, створи upload key і Play App Signing.

На 31 серпня 2026 для нових застосунків Google Play вимагає target Android 16 / API 36.
