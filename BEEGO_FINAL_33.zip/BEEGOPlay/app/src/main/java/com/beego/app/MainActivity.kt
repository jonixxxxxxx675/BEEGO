package com.beego.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private val bg = Color.rgb(8, 10, 10)
    private val panel = Color.rgb(24, 27, 27)
    private val yellow = Color.rgb(255, 193, 7)
    private val white = Color.WHITE
    private val muted = Color.rgb(175, 179, 182)

    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun shell(page: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(20, 14, 16, 8)
        }

        val logo = TextView(this).apply {
            text = "🐝  BEEGO"
            textSize = 23f
            setTextColor(yellow)
            typeface = Typeface.DEFAULT_BOLD
        }

        val cart = Button(this).apply {
            text = "🛒"
            textSize = 20f
            setTextColor(white)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { showCart() }
        }

        header.addView(logo, LinearLayout.LayoutParams(0, 58, 1f))
        header.addView(cart, LinearLayout.LayoutParams(58, 58))
        root.addView(header)

        val scroll = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
        }

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 0, 18, 24)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(panel)
        }
        navButton(nav, "⌂", "Головна") { showHome() }
        navButton(nav, "🍔", "Меню") { showMenu() }
        navButton(nav, "🚁", "Дрон") { showTrack() }
        navButton(nav, "📍", "HUB") { showHubs() }
        navButton(nav, "👤", "Профіль") { showProfile() }
        root.addView(nav, LinearLayout.LayoutParams(-1, 68))

        setContentView(root)
        setTitle(page)
    }

    private fun navButton(parent: LinearLayout, icon: String, label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = "$icon\n$label"
            textSize = 11f
            setTextColor(white)
            setBackgroundColor(Color.TRANSPARENT)
            isAllCaps = false
            setOnClickListener { action() }
        }
        parent.addView(b, LinearLayout.LayoutParams(0, 64, 1f))
    }

    private fun heading(text: String, size: Float = 28f) {
        val t = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 12, 0, 10)
        }
        content.addView(t)
    }

    private fun text(text: String, size: Float = 16f, color: Int = muted) {
        val t = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            setPadding(0, 4, 0, 8)
        }
        content.addView(t)
    }

    private fun card(text: String, action: (() -> Unit)? = null) {
        val b = Button(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(white)
            setBackgroundColor(panel)
            isAllCaps = false
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 0, 18, 0)
            if (action != null) setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, 70)
        lp.setMargins(0, 6, 0, 6)
        content.addView(b, lp)
    }

    private fun primary(text: String, action: () -> Unit) {
        val b = Button(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(Color.BLACK)
            setBackgroundColor(yellow)
            isAllCaps = false
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, 56)
        lp.setMargins(0, 12, 0, 12)
        content.addView(b, lp)
    }

    private fun hero() {
        val h = TextView(this).apply {
            text = "BEEGO\nFOOD DELIVERY BY AIR"
            textSize = 28f
            setTextColor(yellow)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setBackgroundColor(panel)
            setPadding(12, 38, 12, 38)
        }
        content.addView(h, LinearLayout.LayoutParams(-1, 190))
    }

    private fun showHome() {
        shell("BEEGO")
        hero()
        heading("Львів завжди ближче", 25f)
        text("Замовляй їжу — BEEGO доставляє її повітрям.", 17f, white)
        primary("Почати замовлення") { showMenu() }
        card("🍔 Популярне меню") { showMenu() }
        card("🚁 Відстежити доставку") { showTrack() }
        card("📍 Знайти BEEGO HUB") { showHubs() }
        text("🌱 Менше заторів • менше викидів • швидка доставка", 14f)
    }

    private fun showMenu() {
        shell("Меню")
        heading("Меню")
        text("Обери страву для замовлення.")
        card("🍔 BEEGO Burger     189 zł") { product("BEEGO Burger", "189 zł") }
        card("🍟 Crispy Fries        79 zł") { product("Crispy Fries", "79 zł") }
        card("🥤 Fresh Drink         59 zł") { product("Fresh Drink", "59 zł") }
        card("🍕 City Pizza          159 zł") { product("City Pizza", "159 zł") }
    }

    private fun product(name: String, price: String) {
        shell(name)
        heading(name, 25f)
        text(price, 22f, yellow)
        text("Свіжоприготована страва. Доставка BEEGO дроном у доступну зону.", 16f, white)
        primary("Додати в кошик") { showCart() }
        card("← Назад до меню") { showMenu() }
    }

    private fun showCart() {
        shell("Кошик")
        heading("Кошик")
        card("BEEGO Burger                         189 zł")
        card("Доставка дроном                       29 zł")
        heading("Разом                                  218 zł", 21f)
        primary("Оформити замовлення") { showTrack() }
        card("← Повернутися до меню") { showMenu() }
    }

    private fun showTrack() {
        shell("Доставка")
        heading("🚁 Дрон у польоті", 25f)
        text("Замовлення забрано рестораном.", 17f, white)
        card("● Ресторан → HUB", null)
        card("● Дрон летить до точки отримання", null)
        text("Орієнтовний час: 8 хв", 18f, yellow)
        primary("Позначити як доставлено") { showDelivered() }
    }

    private fun showDelivered() {
        shell("Доставлено")
        heading("✓ Доставлено", 30f)
        text("Твоє замовлення успішно доставлено.", 18f, white)
        primary("Нове замовлення") { showMenu() }
    }

    private fun showHubs() {
        shell("BEEGO HUB")
        heading("BEEGO HUB")
        card("📍 Площа Ринок — HUB 01")
        card("📍 Сихів — HUB 02")
        card("📍 Наукова — HUB 03")
        card("📍 Левандівка — HUB 04")
        text("Безпечні точки прийому та видачі замовлень.")
    }

    private fun showProfile() {
        shell("Профіль")
        heading("👤 Мій профіль")
        card("📦 Історія замовлень")
        card("📍 Мої адреси")
        card("💳 Способи оплати")
        card("⭐ BEEGO Plus") { showPlus() }
        card("⚙️ Налаштування")
    }

    private fun showPlus() {
        shell("BEEGO Plus")
        heading("⭐ BEEGO PLUS")
        text("Преміум-можливості BEEGO.", 18f, white)
        card("🚁 Пріоритетна доставка")
        card("🎁 Спеціальні пропозиції")
        card("📦 Переваги для учасників")
        primary("Підключити BEEGO Plus") { showProfile() }
    }

    override fun onBackPressed() {
        showHome()
    }
}
