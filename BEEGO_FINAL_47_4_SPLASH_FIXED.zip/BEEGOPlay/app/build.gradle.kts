plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.beego.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.beego.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 15
        versionName = "4.7.4"
    }

    buildFeatures { buildConfig = true }
}

kotlin { jvmToolchain(17) }
