# BEEGO 3.4 — Menu

Native Android build for the BEEGO food-delivery presentation app.

## Included
- Stable native Android UI (no WebView)
- Menu with categories
- Product details
- Add/remove quantities
- Cart totals in Ukrainian hryvnia (₴)
- Working navigation between menu, cart, delivery, HUB and profile
- BEEGO yellow/black visual style

BEEGO 4.0: fullscreen splash, clickable Start and language selector.
