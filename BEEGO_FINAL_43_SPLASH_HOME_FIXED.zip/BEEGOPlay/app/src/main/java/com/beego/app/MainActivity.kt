package com.beego.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 10, 10)
    private val panel = Color.rgb(25, 28, 28)
    private val panel2 = Color.rgb(33, 36, 36)
    private val yellow = Color.rgb(255, 193, 7)
    private val white = Color.WHITE
    private val muted = Color.rgb(180, 184, 187)
    private val green = Color.rgb(92, 200, 120)

    private data class Product(
        val name: String,
        val category: String,
        val price: Int,
        val emoji: String,
        val description: String
    )

    private val products = listOf(
        Product("BEEGO Burger", "Бургери", 189, "🍔", "Соковита яловичина, сир, салат, томат і фірмовий соус."),
        Product("Chicken Crispy", "Бургери", 179, "🍗", "Хрустка курка, салат, сир та легкий фірмовий соус."),
        Product("City Pizza", "Піца", 159, "🍕", "Моцарела, томати, пепероні та базилік на тонкому тісті."),
        Product("Four Cheese", "Піца", 179, "🧀", "Моцарела, чедер, дорблю та пармезан."),
        Product("Crispy Fries", "Закуски", 79, "🍟", "Хрустка картопля з сіллю та фірмовим соусом."),
        Product("Chicken Wings", "Закуски", 129, "🍗", "Курячі крильця з хрусткою скоринкою та соусом."),
        Product("Fresh Lemonade", "Напої", 59, "🥤", "Холодний лимонад з лимоном та м'ятою."),
        Product("Cola Zero", "Напої", 49, "🥤", "Охолоджений напій без цукру."),
        Product("Cheesecake", "Десерти", 89, "🍰", "Ніжний вершковий чизкейк з ягідним соусом.")
    )

    private val cart = linkedMapOf<String, Int>()
    private lateinit var content: LinearLayout
    private var selectedCategory = "Усе"
    private var selectedHub: String? = null
    private var orderConfirmed = false
    private var trackingStage = 0
    private var paymentMethod = "💳 Банківська картка"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Safe legacy immersive mode: no WindowInsets callbacks and no focus-loop.
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        showSplash()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 18): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun shell(title: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(10), dp(12), dp(8))
        }

        val logo = TextView(this).apply {
            text = "🐝  BEEGO"
            textSize = 23f
            setTextColor(yellow)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(logo, LinearLayout.LayoutParams(0, dp(54), 1f))

        val cartButton = Button(this).apply {
            text = if (cartCount() > 0) "🛒 ${cartCount()}" else "🛒"
            textSize = 15f
            setTextColor(white)
            background = rounded(panel2, 16)
            isAllCaps = false
            setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { showCart() }
        }
        header.addView(cartButton, LinearLayout.LayoutParams(dp(82), dp(48)))
        root.addView(header)

        val titleView = TextView(this).apply {
            text = title
            textSize = 15f
            setTextColor(muted)
            setPadding(dp(18), 0, dp(18), dp(6))
        }
        root.addView(titleView)

        val scroll = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(4), dp(18), dp(24))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(panel)
            setPadding(0, dp(4), 0, dp(4))
        }
        navButton(nav, "⌂", "Головна") { showHome() }
        navButton(nav, "🍔", "Меню") { showMenu() }
        navButton(nav, "🚁", "Дрон") { showTrack() }
        navButton(nav, "📍", "HUB") { showHubs() }
        navButton(nav, "👤", "Профіль") { showProfile() }
        root.addView(nav, LinearLayout.LayoutParams(-1, dp(70)))

        setContentView(root)
    }

    private fun navButton(parent: LinearLayout, icon: String, label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = "$icon\n$label"
            textSize = 10f
            setTextColor(white)
            background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            isAllCaps = false
            setOnClickListener { action() }
        }
        parent.addView(b, LinearLayout.LayoutParams(0, dp(62), 1f))
    }

    private fun heading(value: String, size: Float = 29f) {
        val t = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), 0, dp(8))
        }
        content.addView(t)
    }

    private fun body(value: String, size: Float = 16f, color: Int = muted) {
        val t = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            setPadding(0, dp(2), 0, dp(8))
        }
        content.addView(t)
    }

    private fun sectionLabel(value: String) {
        val t = TextView(this).apply {
            text = value.uppercase()
            textSize = 12f
            setTextColor(yellow)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(18), 0, dp(8))
        }
        content.addView(t)
    }

    private fun categoryBar() {
        val hsv = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val cats = listOf("Усе", "Бургери", "Піца", "Закуски", "Напої", "Десерти")
        cats.forEach { cat ->
            val b = Button(this).apply {
                text = cat
                textSize = 13f
                setTextColor(if (cat == selectedCategory) Color.BLACK else white)
                background = rounded(if (cat == selectedCategory) yellow else panel2, 20)
                isAllCaps = false
                setPadding(dp(15), 0, dp(15), 0)
                setOnClickListener {
                    selectedCategory = cat
                    showMenu()
                }
            }
            val lp = LinearLayout.LayoutParams(dp(104), dp(44))
            lp.setMargins(0, 0, dp(8), 0)
            row.addView(b, lp)
        }
        hsv.addView(row)
        content.addView(hsv, LinearLayout.LayoutParams(-1, dp(50)))
    }

    private fun productCard(p: Product) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(panel, 18)
            setOnClickListener { showProduct(p) }
        }

        val icon = TextView(this).apply {
            text = p.emoji
            textSize = 38f
            gravity = Gravity.CENTER
            background = rounded(panel2, 14)
        }
        card.addView(icon, LinearLayout.LayoutParams(dp(76), dp(76)))

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(8), 0)
        }
        val name = TextView(this).apply {
            text = p.name
            textSize = 18f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        info.addView(name)
        val desc = TextView(this).apply {
            text = p.description
            textSize = 12f
            setTextColor(muted)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        info.addView(desc)
        val price = TextView(this).apply {
            text = "${p.price} ₴"
            textSize = 16f
            setTextColor(yellow)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(5), 0, 0)
        }
        info.addView(price)
        card.addView(info, LinearLayout.LayoutParams(0, dp(86), 1f))

        val add = Button(this).apply {
            text = "+"
            textSize = 27f
            setTextColor(Color.BLACK)
            background = rounded(yellow, 16)
            setOnClickListener {
                cart[p.name] = (cart[p.name] ?: 0) + 1
                showMenu()
            }
        }
        card.addView(add, LinearLayout.LayoutParams(dp(54), dp(54)))

        val lp = LinearLayout.LayoutParams(-1, dp(100))
        lp.setMargins(0, 0, 0, dp(10))
        content.addView(card, lp)
    }

    private fun showMenu() {
        shell("Меню • Львів")
        heading("Що замовимо?", 28f)
        body("Їжа з ресторанів міста — зручно замовити та доставити BEEGO.", 15f)
        categoryBar()

        val list = if (selectedCategory == "Усе") products else products.filter { it.category == selectedCategory }
        sectionLabel(if (selectedCategory == "Усе") "Популярне" else selectedCategory)
        list.forEach { productCard(it) }

        body("🚁 Доставка дроном доступна в зонах покриття BEEGO.", 13f)
    }

    private fun showProduct(p: Product) {
        shell("Товар")
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(panel, 22)
            setPadding(dp(16), dp(22), dp(16), dp(22))
        }
        val emoji = TextView(this).apply { text = p.emoji; textSize = 76f; gravity = Gravity.CENTER }
        hero.addView(emoji, LinearLayout.LayoutParams(-1, dp(115)))
        val title = TextView(this).apply {
            text = p.name
            textSize = 27f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        hero.addView(title)
        val price = TextView(this).apply {
            text = "${p.price} ₴"
            textSize = 24f
            setTextColor(yellow)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(4))
        }
        hero.addView(price)
        val desc = TextView(this).apply {
            text = p.description
            textSize = 15f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(5), dp(8), dp(10))
        }
        hero.addView(desc)
        content.addView(hero, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))

        val add = Button(this).apply {
            text = "Додати в кошик • ${p.price} ₴"
            textSize = 17f
            setTextColor(Color.BLACK)
            background = rounded(yellow, 17)
            isAllCaps = false
            setOnClickListener {
                cart[p.name] = (cart[p.name] ?: 0) + 1
                showProduct(p)
            }
        }
        val addLp = LinearLayout.LayoutParams(-1, dp(58)); addLp.setMargins(0, dp(14), 0, dp(8))
        content.addView(add, addLp)

        secondaryButton("Перейти до кошика") { showCart() }
        secondaryButton("← Повернутися до меню") { showMenu() }
    }

    private fun secondaryButton(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = 15f
            setTextColor(white)
            background = rounded(panel2, 16)
            isAllCaps = false
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, dp(52)); lp.setMargins(0, dp(6), 0, dp(6))
        content.addView(b, lp)
    }

    private fun cartCount(): Int = cart.values.sum()

    private fun showCart() {
        shell("Кошик")
        heading("Кошик", 29f)
        if (cart.isEmpty()) {
            body("🛒 Кошик порожній.", 18f, white)
            body("Обери страви в меню — вони з'являться тут.")
            secondaryButton("Перейти до меню") { showMenu() }
            return
        }

        var subtotal = 0
        cart.entries.toList().forEach { entry ->
            val p = products.firstOrNull { it.name == entry.key } ?: return@forEach
            val qty = entry.value
            subtotal += p.price * qty
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = rounded(panel, 16)
            }
            val name = TextView(this).apply {
                text = "${p.emoji}  ${p.name}\n$qty × ${p.price} ₴"
                textSize = 15f
                setTextColor(white)
            }
            row.addView(name, LinearLayout.LayoutParams(0, dp(64), 1f))
            val minus = Button(this).apply {
                text = "−"; textSize = 20f; setTextColor(white); background = rounded(panel2, 12)
                setOnClickListener {
                    if (qty <= 1) cart.remove(p.name) else cart[p.name] = qty - 1
                    showCart()
                }
            }
            row.addView(minus, LinearLayout.LayoutParams(dp(48), dp(48)))
            val plus = Button(this).apply {
                text = "+"; textSize = 20f; setTextColor(Color.BLACK); background = rounded(yellow, 12)
                setOnClickListener { cart[p.name] = qty + 1; showCart() }
            }
            val plusLp = LinearLayout.LayoutParams(dp(48), dp(48)); plusLp.setMargins(dp(6), 0, 0, 0)
            row.addView(plus, plusLp)
            val lp = LinearLayout.LayoutParams(-1, dp(84)); lp.setMargins(0, 0, 0, dp(8))
            content.addView(row, lp)
        }

        sectionLabel("Підсумок")
        body("Сума страв: $subtotal ₴", 16f, white)
        body("Доставка BEEGO: 29 ₴", 16f, white)
        heading("Разом: ${subtotal + 29} ₴", 24f)
        val order = Button(this).apply {
            text = "Оформити замовлення"
            textSize = 17f
            setTextColor(Color.BLACK)
            background = rounded(yellow, 17)
            isAllCaps = false
            setOnClickListener {
                if (selectedHub == null) showHubs() else showCheckout()
            }
        }
        content.addView(order, LinearLayout.LayoutParams(-1, dp(58)))
        secondaryButton("← Продовжити покупки") { showMenu() }
    }

    private fun showSplash() {
        val root = android.widget.FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val bgImage = ImageView(this).apply {
            setImageBitmap(android.graphics.BitmapFactory.decodeStream(assets.open("splash_bg.jpg")))
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        root.addView(bgImage, android.widget.FrameLayout.LayoutParams(-1, -1))

        val language = Button(this).apply {
            text = "🇺🇦  UA ⌄"
            textSize = 15f
            setTextColor(white)
            background = rounded(Color.argb(90, 20, 24, 25), 24)
            isAllCaps = false
            setPadding(dp(16), 0, dp(16), 0)
            setOnClickListener { showLanguagePopup(this) }
        }
        val langLp = android.widget.FrameLayout.LayoutParams(dp(120), dp(52), Gravity.TOP or Gravity.END)
        langLp.setMargins(0, dp(22), dp(18), 0)
        root.addView(language, langLp)

        val start = Button(this).apply {
            text = "Почати  →"
            textSize = 20f
            setTextColor(Color.BLACK)
            background = rounded(yellow, 24)
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            setOnClickListener { showHome() }
        }
        val startLp = android.widget.FrameLayout.LayoutParams(-1, dp(64), Gravity.BOTTOM)
        startLp.setMargins(dp(34), 0, dp(34), dp(76))
        root.addView(start, startLp)
        setContentView(root)
    }

    private fun showLanguagePopup(anchor: View) {
        val popup = android.widget.PopupWindow(this).apply {
            width = dp(260)
            height = ViewGroup.LayoutParams.WRAP_CONTENT
            isFocusable = true
            elevation = dp(10).toFloat()
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = rounded(panel2, 20)
        }
        val title = TextView(this).apply {
            text = "Мова / Language"
            textSize = 18f
            setTextColor(white)
            setPadding(0, dp(4), 0, dp(8))
        }
        box.addView(title)
        listOf("✓  🇺🇦  Українська", "🇬🇧  English", "🇵🇱  Polski").forEach { lang ->
            val b = Button(this).apply {
                text = lang
                textSize = 16f
                setTextColor(if (lang.startsWith("✓")) yellow else white)
                background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
                isAllCaps = false
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setOnClickListener {
                    bodyToast("Обрано: ${lang.replace("✓  ", "")}")
                    popup.dismiss()
                }
            }
            box.addView(b, LinearLayout.LayoutParams(dp(220), dp(50)))
        }
        popup.contentView = box
        popup.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        popup.showAsDropDown(anchor, -dp(140), dp(8))
    }

    private fun showHome() {
        shell("Львів")

        val location = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, dp(6))
        }
        val pin = TextView(this).apply { text = "📍"; textSize = 27f }
        location.addView(pin, LinearLayout.LayoutParams(dp(42), dp(48)))
        val locText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val city = TextView(this).apply {
            text = "Львів"
            textSize = 21f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        val address = TextView(this).apply {
            text = "Вул. Стрийська, 45 ⌄"
            textSize = 14f
            setTextColor(muted)
        }
        locText.addView(city)
        locText.addView(address)
        location.addView(locText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val bell = Button(this).apply {
            text = "🔔"
            textSize = 20f
            setTextColor(white)
            background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            setOnClickListener { bodyToast("Нових сповіщень немає") }
        }
        location.addView(bell, LinearLayout.LayoutParams(dp(54), dp(50)))
        content.addView(location)

        val hero = ImageView(this).apply {
            setImageBitmap(android.graphics.BitmapFactory.decodeStream(assets.open("home_banner.png")))
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(panel, 22)
            clipToOutline = true
            setOnClickListener { showMenu() }
        }
        val heroLp = LinearLayout.LayoutParams(-1, dp(205))
        heroLp.setMargins(0, 0, 0, dp(12))
        content.addView(hero, heroLp)

        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val rows = listOf(
            listOf("🍔" to "Бургери", "🥣" to "Боулі", "🍕" to "Піца", "🍰" to "Десерти"),
            listOf("☕" to "Напої", "🌿" to "Healthy", "🔥" to "Новинки", "%" to "Акції")
        )
        rows.forEach { rowData ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowData.forEach { pair ->
                val b = Button(this).apply {
                    text = "${pair.first}\n${pair.second}"
                    textSize = 11.5f
                    setTextColor(white)
                    background = rounded(panel, 17)
                    isAllCaps = false
                    setOnClickListener {
                        selectedCategory = when (pair.second) {
                            "Бургери" -> "Бургери"
                            "Піца" -> "Піца"
                            "Десерти" -> "Десерти"
                            "Напої" -> "Напої"
                            else -> "Усе"
                        }
                        showMenu()
                    }
                }
                val lp = LinearLayout.LayoutParams(0, dp(78), 1f)
                lp.setMargins(0, 0, dp(6), dp(6))
                row.addView(b, lp)
            }
            grid.addView(row)
        }
        content.addView(grid)

        val popularHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val popular = TextView(this).apply {
            text = "Популярне"
            textSize = 23f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        popularHeader.addView(popular, LinearLayout.LayoutParams(0, dp(50), 1f))
        val all = Button(this).apply {
            text = "Дивитись всі  ›"
            textSize = 13f
            setTextColor(white)
            background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            isAllCaps = false
            setOnClickListener { showMenu() }
        }
        popularHeader.addView(all, LinearLayout.LayoutParams(dp(132), dp(50)))
        content.addView(popularHeader)

        val productsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val homeProducts = listOf(products[0] to "product_burger.png", products[6] to "product_bowl.png")
        homeProducts.forEach { (p, assetName) ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(panel, 18)
                setPadding(dp(5), dp(5), dp(5), dp(6))
                setOnClickListener { showProduct(p) }
            }
            val image = ImageView(this).apply {
                setImageBitmap(android.graphics.BitmapFactory.decodeStream(assets.open(assetName)))
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = rounded(panel2, 14)
                clipToOutline = true
            }
            card.addView(image, LinearLayout.LayoutParams(-1, dp(105)))
            val name = TextView(this).apply {
                text = p.name
                textSize = 14f
                setTextColor(white)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(6), dp(5), dp(4), 0)
                maxLines = 1
            }
            card.addView(name)
            val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val price = TextView(this).apply {
                text = "${p.price} ₴"
                textSize = 15f
                setTextColor(yellow)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(6), 0, 0, 0)
            }
            bottom.addView(price, LinearLayout.LayoutParams(0, dp(42), 1f))
            val add = Button(this).apply {
                text = "+"
                textSize = 22f
                setTextColor(Color.BLACK)
                background = rounded(yellow, 13)
                setOnClickListener {
                    cart[p.name] = (cart[p.name] ?: 0) + 1
                    showHome()
                }
            }
            bottom.addView(add, LinearLayout.LayoutParams(dp(50), dp(50)))
            card.addView(bottom)
            val lp = LinearLayout.LayoutParams(0, dp(190), 1f)
            lp.setMargins(0, 0, dp(8), 0)
            productsRow.addView(card, lp)
        }
        content.addView(productsRow)
    }

    private fun bodyToast(message: String) {
        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun paymentButton(method: String) {
        val selected = paymentMethod == method
        val label = if (selected) "✓ $method" else method
        secondaryButton(label) {
            paymentMethod = method
            if (selectedHub != null && cart.isNotEmpty()) {
                showCheckout()
            } else {
                showProfileSection("Способи оплати", "Керуй доступними способами оплати замовлень.")
            }
        }
    }

    private fun showCheckout() {
        shell("Оформлення")
        heading("Оформлення замовлення", 27f)
        val hub = selectedHub ?: "Не обрано"
        body("📍 Точка отримання", 13f, yellow)
        secondaryButton("$hub  ›") { showHubs() }

        sectionLabel("Оплата")
        paymentButton("💳 Банківська картка")
        paymentButton("💵 Готівка при отриманні")
        paymentButton("🟢 Google Pay")
        paymentButton(" Apple Pay")
        body("Обрано: $paymentMethod", 14f, yellow)

        val subtotal = cart.entries.sumOf { entry ->
            val product = products.firstOrNull { it.name == entry.key }
            (product?.price ?: 0) * entry.value
        }
        body("Сума страв: $subtotal ₴", 16f, white)
        body("Доставка BEEGO: 29 ₴", 16f, white)
        heading("Разом: ${subtotal + 29} ₴", 24f)

        val confirm = Button(this).apply {
            text = "Підтвердити замовлення"
            textSize = 17f
            setTextColor(Color.BLACK)
            background = rounded(yellow, 17)
            isAllCaps = false
            setOnClickListener {
                orderConfirmed = true
                trackingStage = 1
                showTrack()
            }
        }
        content.addView(confirm, LinearLayout.LayoutParams(-1, dp(58)))
        secondaryButton("← До кошика") { showCart() }
    }

    private fun showTrack() {
        shell("Доставка")
        heading(if (orderConfirmed) "🚁 BEEGO у польоті" else "🚁 Доставка", 25f)
        val hub = selectedHub ?: "HUB не обрано"
        body("📍 Точка отримання: $hub", 16f, white)

        sectionLabel("Статус замовлення")
        val stages = listOf(
            "✓ Замовлення прийнято",
            "✓ Ресторан готує замовлення",
            "🚁 Дрон прямує до HUB",
            "📍 Замовлення прибуло в HUB"
        )
        stages.forEachIndexed { index, stage ->
            val active = index <= trackingStage
            body(if (active) stage else "○ ${stage.removePrefix("✓ ").removePrefix("🚁 ").removePrefix("📍 ")}", 16f, if (active) yellow else muted)
        }

        val time = when (trackingStage) {
            0 -> "Підтвердь замовлення, щоб запустити доставку."
            1 -> "Ресторан готує замовлення."
            2 -> "Дрон вже летить до обраного HUB."
            else -> "Замовлення готове до отримання в HUB."
        }
        body(time, 15f, white)

        if (orderConfirmed && trackingStage < 3) {
            val next = Button(this).apply {
                text = if (trackingStage == 1) "🚁 Дрон вилетів" else "Оновити статус"
                textSize = 17f
                setTextColor(Color.BLACK)
                background = rounded(yellow, 17)
                isAllCaps = false
                setOnClickListener {
                    trackingStage = (trackingStage + 1).coerceAtMost(3)
                    showTrack()
                }
            }
            content.addView(next, LinearLayout.LayoutParams(-1, dp(58)))
        } else if (orderConfirmed) {
            body("🎉 Замовлення прибуло. Можна забирати в HUB.", 17f, yellow)
        }

        secondaryButton("← Повернутися до меню") { showMenu() }
    }

    private fun showHubs() {
        shell("BEEGO HUB")
        heading("BEEGO HUB")
        body("Обери точку отримання замовлення.", 15f)
        val hubs = listOf(
            "Площа Ринок — HUB 01",
            "Сихів — HUB 02",
            "Наукова — HUB 03",
            "Левандівка — HUB 04"
        )
        hubs.forEach { hub ->
            secondaryButton("📍 $hub") { showHubDetails(hub) }
        }
        body("Безпечні точки прийому та видачі замовлень.")
    }

    private fun showHubDetails(hub: String) {
        shell("BEEGO HUB")
        heading(hub, 25f)
        body("🟢 HUB доступний для отримання замовлень.", 16f, white)
        body("🚁 Доставка дроном до точки отримання.", 15f)
        body("⏱ Орієнтовний час: 8–12 хв", 16f, yellow)
        val select = Button(this).apply {
            text = "Обрати цей HUB"
            textSize = 17f
            setTextColor(Color.BLACK)
            background = rounded(yellow, 17)
            isAllCaps = false
            setOnClickListener {
                selectedHub = hub
                trackingStage = 0
                showCart()
            }
        }
        content.addView(select, LinearLayout.LayoutParams(-1, dp(58)))
        secondaryButton("← До списку HUB") { showHubs() }
    }

    private fun showProfile() {
        shell("Профіль")
        heading("👤 Мій профіль")
        body("Керуйте своїми даними та налаштуваннями.", 15f)

        secondaryButton("📦 Історія замовлень  ›") { showProfileSection("Історія замовлень", "Тут будуть усі твої замовлення BEEGO.") }
        secondaryButton("📍 Мої адреси  ›") { showProfileSection("Мої адреси", "Додай HUB-и, які використовуєш найчастіше.") }
        secondaryButton("💳 Способи оплати  ›") { showProfileSection("Способи оплати", "Керуй доступними способами оплати замовлень.") }
        secondaryButton("⭐ BEEGO Plus  ›") { showProfileSection("BEEGO Plus", "Переваги підписки BEEGO Plus та спеціальні умови.") }
    }

    private fun showProfileSection(title: String, description: String) {
        shell("Профіль")
        heading(title, 27f)
        body(description, 16f, white)

        when (title) {
            "Історія замовлень" -> {
                sectionLabel("Замовлення")
                secondaryButton("📦 Замовлення #BEEGO-001") {}
                body("Поки що це демонстраційна історія замовлень.", 14f)
            }
            "Мої адреси" -> {
                sectionLabel("Точки отримання")
                secondaryButton("📍 Площа Ринок — HUB 01") { showHubDetails("Площа Ринок — HUB 01") }
                secondaryButton("📍 Сихів — HUB 02") { showHubDetails("Сихів — HUB 02") }
                secondaryButton("📍 Наукова — HUB 03") { showHubDetails("Наукова — HUB 03") }
                secondaryButton("📍 Левандівка — HUB 04") { showHubDetails("Левандівка — HUB 04") }
            }
            "Способи оплати" -> {
                sectionLabel("Оплата")
                paymentButton("💳 Банківська картка")
                paymentButton("💵 Готівка при отриманні")
                paymentButton("🟢 Google Pay")
                paymentButton(" Apple Pay")
            }
            "BEEGO Plus" -> {
                sectionLabel("Переваги")
                body("⭐ Пріоритетні можливості BEEGO.", 16f, white)
                body("🚁 Зручне відстеження доставки.", 15f)
                body("🎁 Спеціальні пропозиції для учасників.", 15f)
            }
        }
        secondaryButton("← Назад до профілю") { showProfile() }
    }
}
